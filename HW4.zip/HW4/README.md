# **Screencasts and Meeting video links**
[Screencast 1](https://drive.google.com/file/d/15nWy3y66Tza6SZdYT1XjbXhAZCc4xCuz/view?usp=sharing)

[Screencast 2](https://drive.google.com/file/d/1-5fjvpnrl3E7Qj5Yg6ezwTKmhxFbj0yT/view?usp=sharing)

[Standup meeting 1 (3/2/25)](https://drive.google.com/file/d/1QUFJG7w49jMxfYinxw7N7n4cLME8ENli/view?usp=sharing)

[Standup meeting 2 (3/6/25)](https://youtu.be/QmVQ41i6Gew)

[Standup meeting 3 (3/16/25)](https://youtu.be/YRLgK-J17WI)

[Standup meeting 4 (3/20/25)](https://youtu.be/55FK3cl6nss)

[Standup meeting 5 (3/23/25)](https://youtu.be/KYOvqvjXN90)

[Standup meeting 6 (3/27/25)](https://youtu.be/WOKHW94_tbA)

[Standup meeting 7 (3/30/25)](https://youtu.be/V-NpXcLAFuc)

[Standup meeting 8 (4/3/25)](https://youtu.be/AvIBSCnhcWU)

# **NOTE FOR PROPER JUNIT TESTING**
To successfully use the JUnit tests, you must uncomment line 46 (statement.execute("DROP ALL OBJECTS");) in [DatabaseHelper](https://github.com/LordBananza/CSE-360-Wednesday-5/blob/main/src/databasePart1/DatabaseHelper.java).

# **NOTE FOR DISPLAYING CORRECT FONTS AND IMAGES**
This program imports an image and two fonts off of filesystem it runs on. The path is set locally (relative to the project), but the file path is written in Unix format. This means that Windows users will need to manually change the '/' character in the file paths of StartCSE360.java to '\\' instead.

# **David's Updates**
Implemented database table to store requests to become reviewers. Implemented frontend interface to send these requests, along with an interface to accept or deny those requests. Implemented database methods to insert, delete, and select entries from the database to help the instructor make their decision. Documented and tested code related to these functions.

# **Stavros's Updates**
I created the Review and ReviewList classes and added database functionality for posting, editing, and deleting reviews. I also added input validation for posting, editing, and deleting reviews.I also worked on the JUnit tests and ensured that they worked properly. I also added database functionality for students setting specific reviewers as trusted, and sorting them by weight.


# **Sofia's Updates**
I created the updated UML diagrams for TP3 including the Review and Reviewer classes. I also worked with Kirsten to implement menu functionality for students to be able to add reviewers as trusted and to view a list of their trusted reviewers. 

# **Franz's Updates**
I restructured the application to implement a borderpane. I updated the mainview to be wrapped in a scrollpane to handle multiple answers. I added text wrapping to the main view. I added a way to post reviews. I added a way to display answers and reviews and added filter buttons. I added a function to display questions that contain reviews from the user.  I added a button that displays all the trusted reviewers and their weights.

# **Kirsten's Updates**
Made it able for the admin to also be an instructor and can switch between views. Edited the code so reviewers are unable to review their own answer. Then worked with Sofia on adding trusted reviewers for students and to make it so students can sort the reviews so they can only see reviews from their trusted reviewers.

# **Mohammad's Updates**
Created a feedback button for the reviews that reviewers post, and made the feedback inputted become private and not viewable by anyone other than the reviewer. made the private feedback accessible by the reviewers who wrote the review and disabled the button for the student account. Created a private feedback page which a reviewer gets directed to when trying to access private feedback. 


<!--

OLD README FOR TP2
# **Screencasts and Meeting video links**
[Screencast 1](https://drive.google.com/file/d/1cH5P8RC7IOX-11dGC8hf-oRMpLBJWO3p/view)

[Screencast 2](https://drive.google.com/file/d/1I_WBtz71Gqsp09tEUkoVQ1h6N2HhjLp7/view?usp=sharing)

[Standup meeting 1 (2/9/25)](https://youtu.be/s9gbvEAD2Gk)

[Standup meeting 2 (2/13/25)](https://youtu.be/PDZnzNyJAaw)

[Standup meeting 3 (2/16/25)](https://youtu.be/yHxu5c2x4rw)

[Standup meeting 4 (2/20/25)](https://youtu.be/kgpXXPRRXy8)

[Standup meeting 5 (2/23/25)](https://youtu.be/OWEbLOmKbKI)

[Standup meeting 6 (2/27/25)](https://youtu.be/QfG8xKWt9gw)


# **NOTE FOR DISPLAYING CORRECT FONTS AND IMAGES**
This program imports an image and two fonts off of filesystem it runs on. The path is set locally (relative to the project), but the file path is written in Unix format. This means that Windows users will need to manually change the '/' character in the file paths of StartCSE360.java to '\\' instead.

# **David's Updates**
Implemented ability to answer a question, and mark an answer as resolved in frontend. Implemented creating private answers and checks to view private answers in the frontend. Led screencast for creating questions and answers, the automatic search feature when a question is created, along with marking an answer and question as resolved. Recorded and uploaded team meetings. 

# **Stavros's Updates**
I added the Question, Answer, QuestionList, and AnswerList classes from my HW2, and adapted them for this project. I added database functionality for posting, editing, and getting answers. I also modified  the QuestionList and AnswerList classes to work with the new database, and I made testing automation for posting, editing, and deleting questions and answers.

# **Sofia's Updates**
Implemented Mohammad’s search function into the RoleStudentPage to give the student an option to search by keyword. I also created an algorithm to find the most similar question by title before the student submits a new question, and added a “yes” and “no” option for the question to be posted or not. 

# **Franz's Updates**
I edited and adapted Stavros’ question class to work in the database and created functions to insert, delete, and edit questions and other database functions. I also developed the question list and its functionality and the main contents of the question main view. I also developed the delete button, the ask button, and the posting a question form and their functionalities.

# **Kirsten's Updates**
Created the functionality for the edit button on the specific questions which allows a user to edit the question if they were the one that wrote it in the first place, and then it also shows that the question has been edited. Also fixed the code to ensure that the edit and delete button only show once per question. Also worked on explaining the application code and showing that the code worked for the edit and delete questions.

# **Mohammad's Updates**
created the search function which allows users to search for a question similar to the question they had in mind, the search uses keywords from the user’s question to find a similar question in the questions stored in the program while also making sure not to use often used words (like can or and) as the keyword for the search function

OLD README - FOR TP1
# **Screencasts and Meeting video links**
Screencast 1:
https://drive.google.com/file/d/11mYjW2gN_b4HBJjJuNAcQq7QX_R6iUEM/view?usp=sharing

Screencast 2:
https://www.youtube.com/watch?v=qSNJL17Voqc

Standup meeting 1:
https://www.youtube.com/watch?v=Ds6AS1dcYgA

Standup meeting 2:
https://www.youtube.com/watch?v=5XhoN-zyVp8

# **NOTE FOR DISPLAYING CORRECT FONTS AND IMAGES**
This program imports an image and two fonts off of filesystem it runs on. The path is set locally (relative to the project), but the file path is written in Unix format. This means that Windows users will need to manually change the '/' character in the file paths of StartCSE360.java to '\\' instead.

## **David's UI Updates**
I've placed a logo in the top left corner of the UI. Black rectangles surround a smaller bit of whitespace on the top and right sides. Primary text will occupy this whitespace, and secondary text and buttons rest atop the rectangles. The top right corner now displays a greeting message that addresses the user by their name and current role. An imported font is used for most text on the UI. 

SetupLoginSelectionPage now contains a dynamically scaling UI for window resizing.

The pages which include the new UI are:  FirstPage.java  SetupLoginSelectionPage.java  UserHomePage.java  AdminHomePage.java AdminSetupPage.java


## **Stavros's Updates**
Added a deleteUser method and an expiration for invite codes in DatabaseHelper.java

Created testing automation for password, username, and email

Created the email evaluator

## **Sofia's Updates**
Updated UI: SetupAccountPage.java, UserLoginPage.java, AdminModAcc.java, WelcomeLoginPage.java, InvitationPage.java, AdminHomePage.java

## **Franz's Updates**
Added admin home page, account modification page, OTP table and functions, integration of the database, newUser, and admin tasks.
Sources and Acknowledgements:
- Alerts: Oracle Documentation - https://docs.oracle.com/javase/8/javafx/api/javafx/scene/control/Alert.html
- CheckBoxes: Orcale Documentation - https://docs.oracle.com/javase/8/javafx/api/javafx/scene/control/CheckBox.html
--->
