package application;

import QuestionAndAnswer.Question;
import QuestionAndAnswer.QuestionList;
import databasePart1.DatabaseHelper;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.ArrayList;




/**
 * This access the issue reported questions 
 * 
 * Views the questions that have been reported by the staff member 
 */
public class ReportedIssues {
    public void show(Stage primaryStage, DatabaseHelper databaseHelper) {
        VBox layout = new VBox();
        layout.getChildren().add(new Label("Reported Issues:"));

        QuestionList questionList = new QuestionList(databaseHelper);
        ArrayList<Question> allQuestions = questionList.getAllQuestions();

        for (Question question : allQuestions) {
            Label questionLabel = new Label("Question: " + question.getContents());
            layout.getChildren().add(questionLabel);
        }

        Scene scene = new Scene(layout, 800, 400);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Reported Issues");
        primaryStage.show();
        
        
        
        
        
        
        
        
    }
}
