package application;

import java.sql.SQLException;
import java.util.ArrayList;

import QuestionAndAnswer.*;
import Review.Review;
import databasePart1.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

/**
 * This page supports all major functionality for a User.
 * It allows for users to create Questions of their own,
 * provide Answers to others' Questions, and view the private 
 * Answers to their own questions. All of these data structures 
 * are stored in and fetched from a database by a DatabaseHelper.
 * @see databasePart1.DatabaseHelper
 */

public class RoleStudentPage {
	/**
	 * Used to manage the database based on the user's input.
	 */
	private final DatabaseHelper databaseHelper;
	
	/**
	 *  Used to manage the Questions from this class .
	 */
	private QuestionList questionList;
	
	/**
	 * Used to manage the Answers and replies from this class.
	 */
	private AnswerList answerList;
	
	/**
	 * Stores the titles of questions for the user to view.
	 * When a Questions is clicked on, it displays more information
	 * about it next to the ListView.
	 */
	private ListView<String> questionListView = new ListView<>();

	/**
	 * Basic constructor for the class, simply passing down 
	 * the DatabaseHelper from main, and passing it to AnswerList
	 * 
	 * @param databaseHelper The DatbaseHelper passed down from StartCSE360
	 */
    public RoleStudentPage(DatabaseHelper databaseHelper) {
        this.databaseHelper = databaseHelper;
        answerList = new AnswerList(databaseHelper);
        questionList = new QuestionList(databaseHelper);
    }
    
    /**
     * Organizes and displays the UI elements of the home page
     * 
     * @param primaryStage Container for the visual elements to be displayed.
     */
    public void show(Stage primaryStage) {
    	BorderPane main = new BorderPane(); //contains the list of questions and question data
		VBox mainView = new VBox(10); //where the question data is displayed
		VBox questionForm = new VBox(); //screen where user can post questions
		VBox confirmForm = new VBox(); //screen where user sees a similar question and confirms that they want to post theirs
		VBox editForm = new VBox(); //screen where user can edit posts
		VBox answerForm = new VBox(); //screen where user can answer questions
		VBox trustedRevsForm = new VBox(); //screen where user can input trusted reviewers
		HBox userOptions = new HBox(); //contains buttons edit and delete buttons
    	ScrollPane mainViewContainer = new ScrollPane();
    	String username = StartCSE360.currentUser.GetUserName();
        String role = StartCSE360.currentUser.GetRole();
        String roles = databaseHelper.getUserRole(username);
   
		
        BorderPane border = new BorderPane(); // VBox, black rectangles, and central elements
        border.setScaleShape(true);
		VBox rightSide = new VBox(); // Side text and buttons
    	rightSide.setStyle("-fx-background-color: black;");
    	// Used for black parts of background
        HBox topSide = new HBox(10); 
        topSide.setStyle("-fx-background-color: black;");
        topSide.setPrefHeight(75);
        
        mainViewContainer.setFitToWidth(true);
        //mainView.setMaxWidth(border.getWidth());  // Allow resizing dynamically with the window
    	
    	// Load logo and font from StartCSE360
        ImageView iv = new ImageView(StartCSE360.w5);
        iv.setFitWidth(75);
        iv.setFitHeight(75);
        topSide.getChildren().add(iv);
		//Font vr = new Font(20);
		Font vrs = StartCSE360.vrs;
    	
		//Setting up question form
		TextField TitleField = new TextField();
		TitleField.setPromptText("Enter Title");
		TitleField.setMaxWidth(250);
		
		TextField QuestionField = new TextField();
		QuestionField.setPromptText("Enter Question");
		QuestionField.setMaxWidth(250);
		QuestionField.setMaxHeight(50);
		
		CheckBox postAnon = new CheckBox("Post Anonymously?");
	    
		Label errorLabel = new Label("");
		
		Button submitButton = new Button("Submit");
		submitButton.setFont(StartCSE360.vrs);
		
		Button yesButton = new Button("Yes, post");
		submitButton.setFont(StartCSE360.vrs);
		
		Button noButton = new Button("No");
		submitButton.setFont(StartCSE360.vrs);
		
		submitButton.setOnAction(a -> {
			if (TitleField.getLength() > 0 && TitleField.getLength() < 100 && !databaseHelper.doesQuestionExist(TitleField.getText())) {
				if (QuestionField.getLength() > 0 && QuestionField.getLength() < 10000) {
					
					SimilarQuestionSearch qSearch = new SimilarQuestionSearch(databaseHelper);
					Question searchResult = qSearch.findSimilarQuestion(TitleField.getText());
					if(searchResult == null)
					{
						boolean isAnon;
						if (postAnon.isSelected()) {isAnon = true;} else {isAnon=false;}
						questionList.addQuestion(TitleField.getText(), QuestionField.getText(), username, isAnon);
						//databaseHelper.postQuestion(username, TitleField.getText(), QuestionField.getText(), isAnon);
						errorLabel.setText("Question Posted.");
						updateList(databaseHelper.loadQuestions());
						main.setCenter(mainViewContainer);
					}
					else
					{
						main.setCenter(confirmForm);
						errorLabel.setText("A similar question has been found: \n" + searchResult.getTitle() 
						+ "\n" + searchResult.getContents() + "\nDo you wish to proceed with asking your question?");
						
						yesButton.setOnAction(b -> {
							confirmForm.getChildren().clear();
							boolean isAnon;
							if (postAnon.isSelected()) {isAnon = true;} else {isAnon=false;}
							questionList.addQuestion(TitleField.getText(), QuestionField.getText(), username, isAnon);
							errorLabel.setText("Question Posted.");
							updateList(databaseHelper.loadQuestions());
						});
						
						noButton.setOnAction(c -> {
							mainView.getChildren().clear();
							new RoleStudentPage(databaseHelper).show(primaryStage);
						});
						
						confirmForm.getChildren().addAll(errorLabel, yesButton, noButton);
					}	
				}
				else if (QuestionField.getLength() == 0) {
					errorLabel.setText("Question Field cannot be blank.");
				}
				else {
					errorLabel.setText("Question Field cannot be over 10000 characters.");
				}
			}
			else if (databaseHelper.doesQuestionExist(TitleField.getText())) {
				errorLabel.setText("Question already exists.");
			}
			else if (TitleField.getLength() == 0) {
				errorLabel.setText("Title Field cannot be blank.");
			}
			else {
				errorLabel.setText("Title cannot be over 100 characters.");
			}
		});
		questionForm.getChildren().addAll(TitleField, QuestionField, postAnon, errorLabel, submitButton);
		
		//Default display for users
		
		updateList(databaseHelper.loadQuestions());
		
		questionListView.setOnMouseClicked(a -> {
			mainView.getChildren().clear();
			
			Question selectedQuestion = databaseHelper.getQuestionByTitle(questionListView.getSelectionModel().getSelectedItem());
			//Label that displays the title, edited status, and questionID
			Label titleLabel = new Label(selectedQuestion.getTitle() + " #" + selectedQuestion.getID());
			titleLabel.setWrapText(true);
			titleLabel.setTextAlignment(TextAlignment.JUSTIFY);
			titleLabel.setMaxWidth(border.getWidth() - 400);
			titleLabel.setPrefWidth(border.getWidth() - 400);
			titleLabel.setMinHeight(0);
			
			//Label that displays the author
			Label userNameLabel = new Label("");
			if (selectedQuestion.getAnonymity()) {
				userNameLabel.setText("Posted by Anonymous\n");
			}
			else {
				userNameLabel.setText("Posted by " + selectedQuestion.getUserName() + "\n");
			}
			
			//Label that displays the contents fo the question
			Label contentsLabel = new Label(selectedQuestion.getContents());
			contentsLabel.setWrapText(true);
			contentsLabel.setTextAlignment(TextAlignment.JUSTIFY);
			contentsLabel.setMaxWidth(border.getWidth() - 400);
			contentsLabel.setPrefWidth(border.getWidth() - 400);
			contentsLabel.setMinHeight(0);
			
			//Label that displays the dates
			Label dateLabel = new Label(selectedQuestion.getDatePosted());
			
			//Container for the question
			VBox questionBox = new VBox();
			questionBox.getChildren().addAll(titleLabel, userNameLabel, dateLabel, contentsLabel);
			
			//Author Controls
			if (username.equals(selectedQuestion.getUserName())) {
				userOptions.getChildren().clear();
			
				Button editButton = new Button("Edit");
				
				editButton.setOnAction(b -> { //Opens up menu to edit question
					editForm.getChildren().clear();
					
					TextField editTitle = new TextField(selectedQuestion.getTitle());
					editTitle.setMaxWidth(250);
					editTitle.setMaxHeight(50);
					
					TextField editQuestion = new TextField(selectedQuestion.getContents());
					editQuestion.setMaxWidth(250);
					editQuestion.setMaxHeight(50);
					
					boolean isAnon;
					if (postAnon.isSelected()) {isAnon = true;} else {isAnon=false;}
					
					Button saveButton = new Button("Save");
					saveButton.setOnAction(c -> {
						String newTitle = editTitle.getText();
						if(!newTitle.endsWith("(Edited)")) {
							newTitle += " (Edited)";
						}
						//databaseHelper.editQuestion(newTitle, editQuestion.getText(), isAnon, selectedQuestion.getID());
						questionList.editQuestion(selectedQuestion.getID(), newTitle, editQuestion.getText(), isAnon, username);
						updateList(databaseHelper.loadQuestions());
						main.setCenter(mainViewContainer);
					});
					
					editForm.getChildren().addAll(editTitle, editQuestion, postAnon, saveButton);
					main.setCenter(editForm);
				});
				
				Button deleteButton = new Button("Delete");
				
				deleteButton.setOnAction(b -> {
					//databaseHelper.deleteQuestion(selectedQuestion.getID());
					questionList.deleteQuestion(selectedQuestion.getID(), username);
					mainView.getChildren().clear();
					updateList(databaseHelper.loadQuestions());
				});

				userOptions.getChildren().addAll(editButton, deleteButton);
				
				questionBox.getChildren().addAll(userOptions);
				
			} else { // Question was created by someone else
				userOptions.getChildren().clear();
				
				Button answerButton = new Button("Answer Question");
				
				answerButton.setOnAction(b -> { //Opens up menu to write an answer
					System.out.println(selectedQuestion.getID());
					
					answerForm.getChildren().clear();
					
					TextField answerField = new TextField();
					answerField.setPromptText("Enter Question");
					answerField.setMaxWidth(250);
					answerField.setMaxHeight(50);
					
					CheckBox anon = new CheckBox("Answer is anonymous");
					CheckBox privately = new CheckBox("Answer is visible only to the question's poster");
					
					Button submit = new Button("Submit");
					
					Label answerErrorLabel = new Label("");
					
					submit.setOnAction(c -> {
						Boolean anonymous = false;
						Boolean priv = false;
						
						if (anon.isSelected()) {
							anonymous = true;
						}
						if (privately.isSelected()) {
							priv = true;
						}
						String answer = answerField.getText();
						if (answer.length() < 5000) {
							if (answer.length() > 10) {
								//int aid = answerList.getAnswersByQuestion(selectedQuestion.getID()).size()+1;
								AnswerList.addAnswer(selectedQuestion.getID(), -1, -1, answer, username, anonymous, priv); 
								updateList(databaseHelper.loadQuestions());
								main.setCenter(mainViewContainer);
							}
							else {
								answerErrorLabel.setText("Answer cannot be empty.");
							}
						}
						else {
							answerErrorLabel.setText("Answer cannot exceed 5000 characters.");
						}
					});
					
					
					answerForm.getChildren().addAll(answerField, anon, privately, submit, answerErrorLabel);
					main.setCenter(answerForm);
				});
				
				
				userOptions.getChildren().addAll(answerButton);
				questionBox.getChildren().addAll(userOptions);
			}
			
			mainView.getChildren().addAll(questionBox);
			
			HBox filterBox = new HBox();
			Label filterLabel = new Label("Filter: ");
			
			Button showAnsButton = new Button("Answers");
			showAnsButton.setOnAction(b -> {
				mainView.getChildren().remove(2, mainView.getChildren().size());
				//ArrayList<Answer> ans = databaseHelper.getAnswerByQuestion(selectedQuestion.getID()); 
				ArrayList<Answer>ans = answerList.getAnswersByQuestion(selectedQuestion.getID());
				
				for (int ansIndex = 0; ansIndex < ans.size(); ansIndex++) {
					Answer currentAnswer = ans.get(ansIndex);

				    if (currentAnswer.getPrivate()) {
				        
				        continue; 
				    }
					Label ansAuthorLabel = new Label(ans.get(ansIndex).getUserName());
					
					Label ansDateLabel = new Label(ans.get(ansIndex).getDatePosted());
					
					Label ansContentsLabel = new Label(ans.get(ansIndex).getContents());
					ansContentsLabel.setWrapText(true);
					ansContentsLabel.setTextAlignment(TextAlignment.JUSTIFY);
					ansContentsLabel.setMaxWidth(border.getWidth() - 400);
					ansContentsLabel.setPrefWidth(border.getWidth() - 400);
					ansContentsLabel.setMinHeight(0);
					
					VBox answerBox = new VBox();
					answerBox.getChildren().addAll(ansAuthorLabel, ansDateLabel, ansContentsLabel);
					mainView.getChildren().addAll(answerBox);
					
					final int ansFinalIndex = ansIndex;
					
					HBox ansUserOptions = new HBox();
					
					//TODO: Marked resolved button
					if (username.equals(selectedQuestion.getUserName())) {
						
					}
					
					//TODO: Edit and Delete buttons
					if (username.equals(ans.get(ansIndex).getUserName())) {
						Button ansEditButton = new Button("Edit");
						ansEditButton.setOnAction(c ->{ 
							VBox ansEditForm = new VBox();
							TextArea ansEditField = new TextArea();
							ansEditField.setPromptText("Enter Review");
							ansEditField.setWrapText(true);
							ansEditField.setPrefRowCount(1);
							
							ansEditField.setMaxHeight(Double.MAX_VALUE); 
							ansEditField.setMinHeight(0); 
							
							Button revSubmitButton = new Button("Submit");
							revSubmitButton.setOnAction(d -> {
								databaseHelper.editAnswer(ansEditField.getText(), ans.get(ansFinalIndex).getAnonymity(), ans.get(ansFinalIndex).getID());
								mainViewContainer.setContent(mainView);
							});
						
							ansEditForm.getChildren().addAll(ansEditField, revSubmitButton);
							mainViewContainer.setContent(ansEditForm);
						});
						
						Button ansDeleteButton = new Button("Delete");
						ansDeleteButton.setOnAction(c ->{
							answerList.deleteAnswer(ans.get(ansFinalIndex).getID(), username);
						});
						
						ansUserOptions.getChildren().addAll(ansEditButton, ansDeleteButton);
						answerBox.getChildren().addAll(ansUserOptions);
					}
					
				}
			});
			
			//TODO: Button to display reviews
			Button showRevButton = new Button("Reviews");
			showRevButton.setOnAction(b -> {
				mainView.getChildren().remove(2, mainView.getChildren().size());
				ArrayList<Review> rev= databaseHelper.getReviewsByQuestion(selectedQuestion.getID());
				
				for (int revIndex = 0; revIndex < rev.size(); revIndex++) {
					Label revAuthorLabel = new Label(rev.get(revIndex).getUserName());
					
					Label revDateLabel = new Label(rev.get(revIndex).getDatePosted());
					
					Label revContentsLabel = new Label(rev.get(revIndex).getContents());
					Review UsedReview = rev.get(revIndex);
					revContentsLabel.setWrapText(true);
					revContentsLabel.setTextAlignment(TextAlignment.JUSTIFY);
					revContentsLabel.setMaxWidth(border.getWidth() - 400);
					revContentsLabel.setPrefWidth(border.getWidth() - 400);
					revContentsLabel.setMinHeight(0);
					
					VBox reviewBox = new VBox();
					
					//shows the feedback only for the reviewer who wrote the review
					String feedback = UsedReview.getFeedback();
					if (feedback != null && !feedback.isEmpty()) {
						
				
					    if (username.equals(UsedReview.getUserName())) {
					        Label feedbackLabel = new Label("Student Feedback: " + feedback);
					        reviewBox.getChildren().add(feedbackLabel);
					    }
					}
					
					VBox answerContainer = new VBox();
					
					Answer sourceAnswer = databaseHelper.getAnswerByID(rev.get(revIndex).getAnswerID());
					
					Label ansAuthorLabel = new Label(sourceAnswer.getUserName());
					
					Label ansDateLabel = new Label(sourceAnswer.getDatePosted());
					
					Label ansContentsLabel = new Label(sourceAnswer.getContents());
					ansContentsLabel.setWrapText(true);
					ansContentsLabel.setTextAlignment(TextAlignment.JUSTIFY);
					ansContentsLabel.setMaxWidth(border.getWidth() - 400);
					ansContentsLabel.setPrefWidth(border.getWidth() - 400);
					ansContentsLabel.setMinHeight(0);

					//to be able to write and submit the feedback for the reviewer
					TextField feedbackField = new TextField();
					feedbackField.setPromptText("Write feedback ");
					Button submitFeedbackButton = new Button("Send Feedback");

					submitFeedbackButton.setOnAction(e -> {
					    String feedbackText = feedbackField.getText().trim();
					   
					        AnswerList.addAnswer(
					            UsedReview.getQuestionID(),   
					            -1,                                  
					            UsedReview.getID(),           
					            feedbackText,                           
					            username,                            
					            false,                               
					            true                                 
					        );
					       
					        submitFeedbackButton.setText("Feedback Sent");
					       
					   
					});

					VBox feedbackBox = new VBox();
					feedbackBox.getChildren().add(feedbackField);
					feedbackBox.getChildren().add(submitFeedbackButton);
					reviewBox.getChildren().add(feedbackBox);


					
					
					answerContainer.getChildren().addAll(ansAuthorLabel, ansDateLabel, ansContentsLabel);
					reviewBox.getChildren().addAll(revAuthorLabel, revDateLabel, revContentsLabel, answerContainer);
					VBox.setMargin(answerContainer, new Insets(0, 0, 0, 20));
					mainView.getChildren().addAll(reviewBox);
				}
			});
			
			//TODO: Button to display resolved answers
			Button showResButton = new Button("Resolved");
			showResButton.setOnAction(b -> {
				
			});
			
			//TODO: Button to display private answers
			Button showPrivButton = new Button("Private");
			showPrivButton.setOnAction(b -> {
				
			});
			Button trustedRevs = new Button("  Trusted \nReviewers");
			trustedRevs.setOnAction(b -> {
				mainView.getChildren().remove(2, mainView.getChildren().size());
				ArrayList<Review> rev= databaseHelper.getReviewsByQuestion(selectedQuestion.getID());
				
				for (int revIndex = 0; revIndex < rev.size(); revIndex++) {
					ArrayList<String> trusted = databaseHelper.getTrustedReviewers(username);
					for(int i = 0; i < trusted.size(); i++) {
						if((rev.get(revIndex).getUserName()).equals(trusted.get(i))) {
							Label revAuthorLabel = new Label(rev.get(revIndex).getUserName());
							
							Label revDateLabel = new Label(rev.get(revIndex).getDatePosted());
							
							Label revContentsLabel = new Label(rev.get(revIndex).getContents());
							revContentsLabel.setWrapText(true);
							revContentsLabel.setTextAlignment(TextAlignment.JUSTIFY);
							revContentsLabel.setMaxWidth(border.getWidth() - 400);
							revContentsLabel.setPrefWidth(border.getWidth() - 400);
							revContentsLabel.setMinHeight(0);
							
							VBox reviewBox = new VBox();
							VBox answerContainer = new VBox();
							
							Answer sourceAnswer = databaseHelper.getAnswerByID(rev.get(revIndex).getAnswerID());
							
							Label ansAuthorLabel = new Label(sourceAnswer.getUserName());
							
							Label ansDateLabel = new Label(sourceAnswer.getDatePosted());
							
							Label ansContentsLabel = new Label(sourceAnswer.getContents());
							ansContentsLabel.setWrapText(true);
							ansContentsLabel.setTextAlignment(TextAlignment.JUSTIFY);
							ansContentsLabel.setMaxWidth(border.getWidth() - 400);
							ansContentsLabel.setPrefWidth(border.getWidth() - 400);
							ansContentsLabel.setMinHeight(0);
							
							answerContainer.getChildren().addAll(ansAuthorLabel, ansDateLabel, ansContentsLabel);
							reviewBox.getChildren().addAll(revAuthorLabel, revDateLabel, revContentsLabel, answerContainer);
							VBox.setMargin(answerContainer, new Insets(0, 0, 0, 20));
							mainView.getChildren().addAll(reviewBox);
						}
						}
					}
			});
			
			filterBox.getChildren().addAll(filterLabel, showAnsButton, showRevButton, showResButton, showPrivButton, trustedRevs);
			mainView.getChildren().addAll(filterBox);
			main.setCenter(mainViewContainer);
		});
		
		mainViewContainer.setContent(mainView);
		
		main.setLeft(questionListView);
	    main.setCenter(mainViewContainer);
		
	    //Search functions
	    HBox searchForm = new HBox();
	    
	    TextField SearchField = new TextField();
		SearchField.setPromptText("Enter search keyword(s) separated by a space");
		SearchField.setMaxWidth(500);
		
		Label searchErrorLabel = new Label("");
		
		Button searchSubmitButton = new Button("Submit");
		searchSubmitButton.setFont(StartCSE360.vrs);
		searchSubmitButton.setOnAction(a -> {
			QuestionList q1 = new QuestionList(databaseHelper);
			q1.getAllQuestions();
			
			if (SearchField.getLength() > 3 && SearchField.getLength() <= 100) {
				//public ArrayList<Question> searching_questions(String userSearch)
				ArrayList<Question> keywordSet = q1.searching_questions(SearchField.getText());
				updateList(keywordSet);
				
				
			}
			else if (SearchField.getLength() < 4) {
				searchErrorLabel.setText("Keyword Field must be at least 4 characters.");
			}
			else {
				searchErrorLabel.setText("Keyword Field cannot be over 100 characters.");
			}
			
			main.setCenter(mainViewContainer);
		});
		searchForm.getChildren().addAll(SearchField, searchSubmitButton, searchErrorLabel);
	    
		topSide.getChildren().addAll(searchForm);
		
	    // label to display the welcome message for the user
        String l = "Hello, " + username + "!\nYou're in Student\nmode right now.";
	    Text label = new Text(l);
	    label.setFont(vrs);
        label.setFill(Color.WHITE);
        
        //Button to ask a question
        Button askButton = new Button("Ask");
        askButton.setFont(StartCSE360.vrs);
        askButton.setOnAction(a -> {
        	TitleField.clear();
        	QuestionField.clear();
        	main.setCenter(questionForm);
        });
	    
        //Button to logout
        Button logoutButton = new Button("Logout");
        logoutButton.setFont(StartCSE360.vrs);
        logoutButton.setOnAction(a -> {
            new UserLoginPage(databaseHelper).show(primaryStage);
        });
        
        Button requestReviewer = new Button(" Request\nReviewer\n  Access");
        requestReviewer.setFont(StartCSE360.vrs);
        requestReviewer.setOnAction(a -> {
        	//TODO Submit a request to be a reviewer
        	databaseHelper.submitReviewerRequest(username);
        });
        
        
        Button addTrustedRevs = new Button("Add Trusted \n  Reviewers");
        addTrustedRevs.setFont(StartCSE360.vrs);
        addTrustedRevs.setOnAction(a -> {
        	//adds everything that is needed for the adding a trusted reviewer part
            TextField UserNameField = new TextField();
            UserNameField.setPromptText("Enter Reviewer Username");
            UserNameField.setMaxWidth(300);
            UserNameField.clear();
            
            Label trustLabel = new Label("Weight for reviewer is from 0-10. 0 is the most trusted and 10 is the least trusted.\n");
            TextField WeightField = new TextField();
            WeightField.setPromptText("Enter Weight for Reviewer");
            WeightField.setMaxWidth(250);
            WeightField.setMaxHeight(50);
            WeightField.clear();
            
            Label errorTrustLabel = new Label("");
            trustedRevsForm.getChildren().clear();
            
            Button submitTrustButton = new Button("Submit");
            submitTrustButton.setFont(StartCSE360.vrs);
            submitTrustButton.setOnAction(b -> {
            	String revUserName = UserNameField.getText();
            	int weightofRev = Integer.parseInt(WeightField.getText());
            	if(databaseHelper.doesUserExist(revUserName)) {
            		if(databaseHelper.getUserRole(revUserName).charAt(4) == '1') {
            		databaseHelper.addTrustedReviewer(username, revUserName, weightofRev);
                	main.setCenter(mainViewContainer);
            		}
            	}
            });
        	
            trustedRevsForm.getChildren().addAll(UserNameField, WeightField, submitTrustButton);
            main.setCenter(trustedRevsForm);
        });

        Button listReviewers = new Button("Trusted Reviewers");
        listReviewers.setFont(StartCSE360.vrs);
        listReviewers.setOnAction(a -> {
        	mainView.getChildren().clear();
        	Label listReviewersLabel = new Label("List of trusted reviewers: \n" + databaseHelper.listTrustedReviewers(username));
        	mainView.getChildren().addAll(listReviewersLabel);
        });
        
        //Setting up borderpane (only show requestReviewer button when the Student has no reviewer role yet)
	    rightSide.getChildren().addAll(label, logoutButton, askButton, addTrustedRevs, listReviewers);
	    if (roles.charAt(4)=='0') {
	    	rightSide.getChildren().addAll(requestReviewer);
	    }
	    
	    rightSide.setAlignment(Pos.TOP_CENTER);
	    rightSide.setSpacing(10);
	    border.setTop(topSide);
	    border.setRight(rightSide);
	    border.setLeft(main);
	    
	    Scene scene = new Scene(border, 800, 400);
	    // Set the scene to primary stage
	    primaryStage.setScene(scene);
	    primaryStage.setTitle("Student Page");
	    primaryStage.show();
    	
    }
    
    /**
     * Resets QuestionListView to only contain the results of the Student's search
     * 
     * @param listOfQs a list of Questions that will serve as search results.
     */
    public void updateList(ArrayList<Question> listOfQs) {
		questionListView.getItems().clear();
		
		if (listOfQs.size() > 0) {
			for (int i = 0; i < listOfQs.size(); i++) {
				questionListView.getItems().add(listOfQs.get(i).getTitle());
			}
		}
		else {
			questionListView.getItems().add("There are currently no questions.");
		}
		
		
    }
}
