package application;

import java.sql.SQLException;
import java.util.ArrayList;

import QuestionAndAnswer.*;
import Review.Review;
import Review.ReviewList;
import databasePart1.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

/**
 * This page displays a simple welcome message for the user.
 */

public class RoleReviewerPage {
	private final DatabaseHelper databaseHelper;
	private ReviewList reviewList;
	private QuestionList questionList;
	private AnswerList answerList;
	private ListView<String> questionListView = new ListView<>();

    public RoleReviewerPage(DatabaseHelper databaseHelper) {
        this.databaseHelper = databaseHelper;
        reviewList = new ReviewList(databaseHelper);
        answerList = new AnswerList(databaseHelper);
        questionList = new QuestionList(databaseHelper);
        
    }
    public void show(Stage primaryStage) {
    	BorderPane main = new BorderPane(); //contains the list of questions and question data
		VBox mainView = new VBox(10); //where the question data is displayed
		VBox questionForm = new VBox(); //screen where user can post questions
		VBox confirmForm = new VBox(); //screen where user sees a similar question and confirms that they want to post theirs
		VBox editForm = new VBox(); //screen where user can edit posts
		VBox answerForm = new VBox(); //screen where user can answer questions
		HBox userOptions = new HBox(); //contains buttons edit and delete buttons
    	ScrollPane mainViewContainer = new ScrollPane();
    	String username = StartCSE360.currentUser.GetUserName();
        String role = StartCSE360.currentUser.GetRole();
   
		
        BorderPane border = new BorderPane(); // VBox, black rectangles, and central elements
        border.setScaleShape(true);
		VBox rightSide = new VBox(); // Side text and buttons
    	rightSide.setStyle("-fx-background-color: black;");
    	// Used for black parts of background
        HBox topSide = new HBox(10); 
        topSide.setStyle("-fx-background-color: black;");
        topSide.setPrefHeight(75);
        
        mainViewContainer.setFitToWidth(true);
        //mainView.setMaxWidth(border.getWidth());  // Allow resizing dynamically with the window
    	
    	// Load logo and font from StartCSE360
        ImageView iv = new ImageView(StartCSE360.w5);
        iv.setFitWidth(75);
        iv.setFitHeight(75);
        topSide.getChildren().add(iv);
		//Font vr = new Font(20);
		Font vrs = StartCSE360.vrs;
    	
		//Setting up question form
		TextField TitleField = new TextField();
		TitleField.setPromptText("Enter Title");
		TitleField.setMaxWidth(250);
		
		TextField QuestionField = new TextField();
		QuestionField.setPromptText("Enter Question");
		QuestionField.setMaxWidth(250);
		QuestionField.setMaxHeight(50);
		
		CheckBox postAnon = new CheckBox("Post Anonymously?");
	    
		Label errorLabel = new Label("");
		
		Button submitButton = new Button("Submit");
		submitButton.setFont(StartCSE360.vrs);
		
		Button yesButton = new Button("Yes, post");
		submitButton.setFont(StartCSE360.vrs);
		
		Button noButton = new Button("No");
		submitButton.setFont(StartCSE360.vrs);
		
		submitButton.setOnAction(a -> {
			if (TitleField.getLength() > 0 && TitleField.getLength() < 100 && !databaseHelper.doesQuestionExist(TitleField.getText())) {
				if (QuestionField.getLength() > 0 && QuestionField.getLength() < 10000) {
					
					SimilarQuestionSearch qSearch = new SimilarQuestionSearch(databaseHelper);
					Question searchResult = qSearch.findSimilarQuestion(TitleField.getText());
					if(searchResult == null)
					{
						boolean isAnon;
						if (postAnon.isSelected()) {isAnon = true;} else {isAnon=false;}
						databaseHelper.postQuestion(username, TitleField.getText(), QuestionField.getText(), isAnon);
						errorLabel.setText("Question Posted.");
						updateList(questionList.getAllQuestions());
						main.setCenter(mainViewContainer);
					}
					else
					{
						main.setCenter(confirmForm);
						errorLabel.setText("A similar question has been found: \n" + searchResult.getTitle() 
						+ "\n" + searchResult.getContents() + "\nDo you wish to proceed with asking your question?");
						
						yesButton.setOnAction(b -> {
							confirmForm.getChildren().clear();
							boolean isAnon;
							if (postAnon.isSelected()) {isAnon = true;} else {isAnon=false;}
							questionList.addQuestion(TitleField.getText(), QuestionField.getText(), username, isAnon);
							errorLabel.setText("Question Posted.");
							updateList(questionList.getAllQuestions());
						});
						
						noButton.setOnAction(c -> {
							mainView.getChildren().clear();
							new RoleStudentPage(databaseHelper).show(primaryStage);
						});
						
						confirmForm.getChildren().addAll(errorLabel, yesButton, noButton);
					}	
				}
				else if (QuestionField.getLength() == 0) {
					errorLabel.setText("Question Field cannot be blank.");
				}
				else {
					errorLabel.setText("Question Field cannot be over 10000 characters.");
				}
			}
			else if (databaseHelper.doesQuestionExist(TitleField.getText())) {
				errorLabel.setText("Question already exists.");
			}
			else if (TitleField.getLength() == 0) {
				errorLabel.setText("Title Field cannot be blank.");
			}
			else {
				errorLabel.setText("Title cannot be over 100 characters.");
			}
		});
		questionForm.getChildren().addAll(TitleField, QuestionField, postAnon, errorLabel, submitButton);
		
		//Default display for users
		
		updateList(questionList.getAllQuestions());
		
		questionListView.setOnMouseClicked(a -> {
			mainView.getChildren().clear();
			
			Question selectedQuestion = databaseHelper.getQuestionByTitle(questionListView.getSelectionModel().getSelectedItem());
			
			//Label that displays the title, edited status, and questionID
			Label titleLabel = new Label(selectedQuestion.getTitle() + " #" + selectedQuestion.getID());
			titleLabel.setWrapText(true);
			titleLabel.setTextAlignment(TextAlignment.JUSTIFY);
			titleLabel.setMaxWidth(border.getWidth() - 400);
			titleLabel.setPrefWidth(border.getWidth() - 400);
			titleLabel.setMinHeight(0);
			
			//Label that displays the author
			Label userNameLabel = new Label("");
			if (selectedQuestion.getAnonymity()) {
				userNameLabel.setText("Posted by Anonymous\n");
			}
			else {
				userNameLabel.setText("Posted by " + selectedQuestion.getUserName() + "\n");
			}
			
			//Label that displays the contents fo the question
			Label contentsLabel = new Label(selectedQuestion.getContents());
			contentsLabel.setWrapText(true);
			contentsLabel.setTextAlignment(TextAlignment.JUSTIFY);
			contentsLabel.setMaxWidth(border.getWidth() - 400);
			contentsLabel.setPrefWidth(border.getWidth() - 400);
			contentsLabel.setMinHeight(0);
			
			//Label that displays the dates
			Label dateLabel = new Label(selectedQuestion.getDatePosted());
			
			//Container for the question
			VBox questionBox = new VBox();
			questionBox.getChildren().addAll(titleLabel, userNameLabel, dateLabel, contentsLabel);
			
			//Author Controls
			if (username.equals(selectedQuestion.getUserName())) {
				userOptions.getChildren().clear();
			
				Button editButton = new Button("Edit");
				
				editButton.setOnAction(b -> { //Opens up menu to edit question
					editForm.getChildren().clear();
					
					TextField editTitle = new TextField(selectedQuestion.getTitle());
					editTitle.setMaxWidth(250);
					editTitle.setMaxHeight(50);
					
					TextField editQuestion = new TextField(selectedQuestion.getContents());
					editQuestion.setMaxWidth(250);
					editQuestion.setMaxHeight(50);
					
					boolean isAnon;
					if (postAnon.isSelected()) {isAnon = true;} else {isAnon=false;}
					
					Button saveButton = new Button("Save");
					saveButton.setOnAction(c -> {
						String newTitle = editTitle.getText();
						if(!newTitle.endsWith("(Edited)")) {
							newTitle += " (Edited)";
						}
						databaseHelper.editQuestion(newTitle, editQuestion.getText(), isAnon, selectedQuestion.getID());
						updateList(questionList.getAllQuestions());
						main.setCenter(mainViewContainer);
					});
					
					editForm.getChildren().addAll(editTitle, editQuestion, postAnon, saveButton);
					main.setCenter(editForm);
				});
				
				Button deleteButton = new Button("Delete");
				
				deleteButton.setOnAction(b -> {
					databaseHelper.deleteQuestion(selectedQuestion.getID());
					mainView.getChildren().clear();
					updateList(questionList.getAllQuestions());
				});

				userOptions.getChildren().addAll(editButton, deleteButton);
				
				questionBox.getChildren().addAll(userOptions);
				
			} else { // Question was created by someone else
				userOptions.getChildren().clear();
				
				Button answerButton = new Button("Answer Question");
				
				answerButton.setOnAction(b -> { //Opens up menu to write an answer
					System.out.println(selectedQuestion.getID());
					
					answerForm.getChildren().clear();
					
					TextField answerField = new TextField();
					answerField.setPromptText("Enter Question");
					answerField.setMaxWidth(250);
					answerField.setMaxHeight(50);
					
					CheckBox anon = new CheckBox("Answer is anonymous");
					CheckBox privately = new CheckBox("Answer is visible only to the question's poster");
					
					Button submit = new Button("Submit");
					
					Label answerErrorLabel = new Label("");
					
					submit.setOnAction(c -> {
						Boolean anonymous = false;
						Boolean priv = false;
						
						if (anon.isSelected()) {
							anonymous = true;
						}
						if (privately.isSelected()) {
							priv = true;
						}
						String answer = answerField.getText();
						if (answer.length() < 5000) {
							if (answer.length() > 0) {
								answerList.addAnswer(selectedQuestion.getID(), -1, -1, answer, username, anonymous, priv); 
								updateList(questionList.getAllQuestions());
								main.setCenter(mainViewContainer);
							}
							else {
								answerErrorLabel.setText("Answer cannot be empty.");
							}
						}
						else {
							answerErrorLabel.setText("Answer cannot exceed 5000 characters.");
						}
					});
					
					
					answerForm.getChildren().addAll(answerField, anon, privately, submit, answerErrorLabel);
					main.setCenter(answerForm);
				});
				
				
				userOptions.getChildren().addAll(answerButton);
				questionBox.getChildren().addAll(userOptions);
			}
			
			mainView.getChildren().addAll(questionBox);
			
			HBox filterBox = new HBox();
			Label filterLabel = new Label("Filter: ");
			
			Button showAnsButton = new Button("Answers");
			showAnsButton.setOnAction(b -> {
				mainView.getChildren().remove(2, mainView.getChildren().size());
				ArrayList<Answer> ans = databaseHelper.getAnswerByQuestion(selectedQuestion.getID()); 
				
				for (int ansIndex = 0; ansIndex < ans.size(); ansIndex++) {
					Label ansAuthorLabel = new Label(ans.get(ansIndex).getUserName());
					
					Label ansDateLabel = new Label(ans.get(ansIndex).getDatePosted());
					
					Label ansContentsLabel = new Label(ans.get(ansIndex).getContents());
					ansContentsLabel.setWrapText(true);
					ansContentsLabel.setTextAlignment(TextAlignment.JUSTIFY);
					ansContentsLabel.setMaxWidth(border.getWidth() - 400);
					ansContentsLabel.setPrefWidth(border.getWidth() - 400);
					ansContentsLabel.setMinHeight(0);
					
					VBox answerBox = new VBox();
					answerBox.getChildren().addAll(ansAuthorLabel, ansDateLabel, ansContentsLabel);
					
					final int ansFinalIndex = ansIndex;
					
					if (!username.equals(ans.get(ansIndex).getUserName())) {
					Button reviewButton = new Button("Review");
					reviewButton.setOnAction(c ->{
						VBox reviewForm = new VBox();
						
						TextArea reviewField = new TextArea();
						reviewField.setPromptText("Enter Review");
						reviewField.setWrapText(true);
						reviewField.setPrefRowCount(1);
						
						reviewField.setMaxHeight(Double.MAX_VALUE); 
						reviewField.setMinHeight(0); 
						
						Button reviewSubmitButton = new Button("Submit");
						reviewSubmitButton.setOnAction(d -> {
							databaseHelper.postReview(ans.get(ansFinalIndex).getQuestionID(), ans.get(ansFinalIndex).getID(), username, reviewField.getText());
							mainViewContainer.setContent(mainView);
						});
						
						reviewForm.getChildren().addAll(reviewField, reviewSubmitButton);
						mainViewContainer.setContent(reviewForm);
					});
					answerBox.getChildren().addAll(reviewButton);
					}
					mainView.getChildren().addAll(answerBox);
				}
			});
			
			//TODO: Button to display reviews
			Button showRevButton = new Button("Reviews");
			showRevButton.setOnAction(b -> {
				mainView.getChildren().remove(2, mainView.getChildren().size());
				ArrayList<Review> rev= databaseHelper.getReviewsByQuestion(selectedQuestion.getID());
				
				for (int revIndex = 0; revIndex < rev.size(); revIndex++) {
					Label revAuthorLabel = new Label(rev.get(revIndex).getUserName());
					
					Label revDateLabel = new Label(rev.get(revIndex).getDatePosted());
					
					Label revContentsLabel = new Label(rev.get(revIndex).getContents());
					revContentsLabel.setWrapText(true);
					revContentsLabel.setTextAlignment(TextAlignment.JUSTIFY);
					revContentsLabel.setMaxWidth(border.getWidth() - 25);
					revContentsLabel.setPrefWidth(border.getWidth() - 400);
					revContentsLabel.setMinHeight(0);
					
					VBox reviewBox = new VBox();
					VBox answerContainer = new VBox();
					
					Answer sourceAnswer = databaseHelper.getAnswerByID(rev.get(revIndex).getAnswerID());
					
					Label ansAuthorLabel = new Label(sourceAnswer.getUserName());
					
					Label ansDateLabel = new Label(sourceAnswer.getDatePosted());
					
					Label ansContentsLabel = new Label(sourceAnswer.getContents());
					ansContentsLabel.setWrapText(true);
					ansContentsLabel.setTextAlignment(TextAlignment.JUSTIFY);
					ansContentsLabel.setMaxWidth(border.getWidth() - 420);
					ansContentsLabel.setPrefWidth(border.getWidth() - 420);
					ansContentsLabel.setMinHeight(0);
					
					answerContainer.getChildren().addAll(ansAuthorLabel, ansDateLabel, ansContentsLabel);
					reviewBox.getChildren().addAll(revAuthorLabel, revDateLabel, revContentsLabel, answerContainer);
					VBox.setMargin(answerContainer, new Insets(0, 0, 0, 20));
					
					final int revFinalIndex = revIndex;
					
					HBox revUserOptions = new HBox();
					
					if (username.equals(rev.get(revIndex).getUserName())) {
						
						Button revEditButton = new Button("Edit");
						revEditButton.setOnAction(c ->{ 
							VBox revEditForm = new VBox();
							TextArea revEditField = new TextArea();
							revEditField.setPromptText("Enter Review");
							revEditField.setWrapText(true);
							revEditField.setPrefRowCount(1);
							
							revEditField.setMaxHeight(Double.MAX_VALUE); 
							revEditField.setMinHeight(0); 
							
							Button revSubmitButton = new Button("Submit");
							revSubmitButton.setOnAction(d -> {
								databaseHelper.editReview(rev.get(revFinalIndex).getID(), revEditField.getText());
								mainViewContainer.setContent(mainView);
							});
						
							revEditForm.getChildren().addAll(revEditField, revSubmitButton);
							mainViewContainer.setContent(revEditForm);
						});
						
						Button revDeleteButton = new Button("Delete");
						revDeleteButton.setOnAction(c ->{
							reviewList.deleteReview(rev.get(revFinalIndex).getID(), username);
						});
						
						revUserOptions.getChildren().addAll(revEditButton, revDeleteButton);
						reviewBox.getChildren().addAll(revUserOptions);
					}
					
					mainView.getChildren().addAll(reviewBox);
				}
			});
			
			//TODO: Button to display resolved answers
			Button showResButton = new Button("Resolved");
			showResButton.setOnAction(b -> {
				
			});


			//TODO: Button to display private feedbacks
			Button showFeedbackButton = new Button("Private");
			showFeedbackButton.setOnAction(b -> {
				new PrivateFeedbackPage().show(primaryStage, username, selectedQuestion.getID(), databaseHelper);

			});
			
			//TODO: Button to display private answers
			Button showPrivButton = new Button("My Reviews");
			showPrivButton.setOnAction(b -> {
				mainView.getChildren().remove(2, mainView.getChildren().size());
				ArrayList<Review> rev= reviewList.getAllReviewsByUserAndQuestion(username, selectedQuestion.getID());
				
				for (int revIndex = 0; revIndex < rev.size(); revIndex++) {
					Label revAuthorLabel = new Label(rev.get(revIndex).getUserName());
					
					Label revDateLabel = new Label(rev.get(revIndex).getDatePosted());
					
					Label revContentsLabel = new Label(rev.get(revIndex).getContents());
					revContentsLabel.setWrapText(true);
					revContentsLabel.setTextAlignment(TextAlignment.JUSTIFY);
					revContentsLabel.setMaxWidth(border.getWidth() - 25);
					revContentsLabel.setPrefWidth(border.getWidth() - 400);
					revContentsLabel.setMinHeight(0);
					
					VBox reviewBox = new VBox();
					VBox answerContainer = new VBox();
					
					Answer sourceAnswer = databaseHelper.getAnswerByID(rev.get(revIndex).getAnswerID());
					
					Label ansAuthorLabel = new Label(sourceAnswer.getUserName());
					
					Label ansDateLabel = new Label(sourceAnswer.getDatePosted());
					
					Label ansContentsLabel = new Label(sourceAnswer.getContents());
					ansContentsLabel.setWrapText(true);
					ansContentsLabel.setTextAlignment(TextAlignment.JUSTIFY);
					ansContentsLabel.setMaxWidth(border.getWidth() - 420);
					ansContentsLabel.setPrefWidth(border.getWidth() - 420);
					ansContentsLabel.setMinHeight(0);
					
					answerContainer.getChildren().addAll(ansAuthorLabel, ansDateLabel, ansContentsLabel);
					reviewBox.getChildren().addAll(revAuthorLabel, revDateLabel, revContentsLabel, answerContainer);
					VBox.setMargin(answerContainer, new Insets(0, 0, 0, 20));
					mainView.getChildren().addAll(reviewBox);
				}
			});
			
			filterBox.getChildren().addAll(filterLabel, showAnsButton, showRevButton, showResButton, showPrivButton, showFeedbackButton);
			mainView.getChildren().addAll(filterBox);
			main.setCenter(mainViewContainer);
		});
		
		mainViewContainer.setContent(mainView);
		
		main.setLeft(questionListView);
	    main.setCenter(mainViewContainer);
		
	    //Search functions
	    HBox searchForm = new HBox();
	    
	    TextField SearchField = new TextField();
		SearchField.setPromptText("Enter keyword(s) separated by a space");
		SearchField.setMaxWidth(500);
		
		Label searchErrorLabel = new Label("");
		
		Button searchSubmitButton = new Button("Submit");
		searchSubmitButton.setFont(StartCSE360.vrs);
		searchSubmitButton.setOnAction(a -> {
			QuestionList q1 = new QuestionList(databaseHelper);
			q1.getAllQuestions();
			
			if (SearchField.getLength() > 3 && SearchField.getLength() <= 100) {
				//public ArrayList<Question> searching_questions(String userSearch)
				ArrayList<Question> keywordSet = q1.searching_questions(SearchField.getText());
				updateList(keywordSet);
				
				
			}
			else if (SearchField.getLength() < 4) {
				searchErrorLabel.setText("Keyword Field must be at least 4 characters.");
			}
			else {
				searchErrorLabel.setText("Keyword Field cannot be over 100 characters.");
			}
			
			main.setCenter(mainViewContainer);
		});
		searchForm.getChildren().addAll(SearchField, searchSubmitButton, searchErrorLabel);
	    
		topSide.getChildren().addAll(searchForm);
		
	    // label to display the welcome message for the user
        String l = "Hello, " + username + "!\nYou're in Reviewer\nmode right now.";
	    Text label = new Text(l);
	    label.setFont(vrs);
        label.setFill(Color.WHITE);
        
        //Button to ask a question
        Button myReviews = new Button("My Reviews");
        myReviews.setFont(StartCSE360.vrs);
        myReviews.setOnAction(a -> {
        	updateList(questionList.getQuestionsByReviewer(username));
        });
        
        Button viewQuestions = new Button("View Questions");
        viewQuestions.setFont(StartCSE360.vrs);
        viewQuestions.setOnAction(a -> {
        	updateList(questionList.getAllQuestions());
        });
        
        
	    
        //Button to logout
        Button logoutButton = new Button("Logout");
        logoutButton.setFont(StartCSE360.vrs);
        logoutButton.setOnAction(a -> {
            new UserLoginPage(databaseHelper).show(primaryStage);
        });

        //Setting up borderpane
	    rightSide.getChildren().addAll(label, logoutButton, myReviews, viewQuestions);
	    rightSide.setAlignment(Pos.TOP_CENTER);
	    border.setTop(topSide);
	    border.setRight(rightSide);
	    border.setLeft(main);
	    
	    // Set the scene to primary stage
	    Scene scene = new Scene(border, 800, 400);
	    primaryStage.setScene(scene);
	    primaryStage.setTitle("Reviewer Page");
	    primaryStage.show();
    	
    }
    
    public void updateList(ArrayList<Question> listOfQs) {
		questionListView.getItems().clear();
		
		if (listOfQs.size() > 0) {
			for (int i = 0; i < listOfQs.size(); i++) {
				questionListView.getItems().add(listOfQs.get(i).getTitle());
			}
		}
		else {
			questionListView.getItems().add("There are currently no questions.");
		}
		
		
    }
}
