package application;

import databasePart1.DatabaseHelper;
import QuestionAndAnswer.*;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

import java.util.ArrayList;

import databasePart1.*;


/**
 * This is the home page for Instructors. 
 * From here, they can review the recent requests of 
 * students to become reviewers, and choose to accept or decline them.
 * The DatabaseHelper class will be used to collect these requests and enact
 * the effects of accepting them.
 * @see databasePart1.DatabaseHelper
 */
public class RoleInstructorPage {
	
	/**
	 * Used to manage the database from within this class.
	 */
	private final DatabaseHelper databaseHelper;

	/**
	 * Basic constructor for the class, simply passing down 
	 * the DatabaseHelper from main.
	 * 
	 * @param databaseHelper The DatbaseHelper passed down from StartCSE360
	 */
    public RoleInstructorPage(DatabaseHelper databaseHelper) {
        this.databaseHelper = databaseHelper;
    }
    
    
    /**
     * Organizes and displays the UI elements of the home page
     * 
     * @param primaryStage Container for the visual elements to be displayed.
     */
    public void show(Stage primaryStage) {
    	
    	Group elements = new Group(); // Contains all scene elements
		Scene scene = new Scene(elements, 800, 400);
        BorderPane border = new BorderPane(); // VBox, black rectangles, and central elements
		VBox rightSide = new VBox(); // Side text and buttons
		
    	
    	// Used for black parts of background
        Rectangle top = new Rectangle(); 
        Rectangle side = new Rectangle();
        
        //Used to coordinate list of requests to become reviewers
        ListView<String> reviewerRequests = new ListView<String>();
        Label introduction = new Label();
        Label approvalQuestion = new Label("Approve this request?");
        approvalQuestion.setTextAlignment(TextAlignment.CENTER);
        VBox requestInfo = new VBox();
        HBox reviewElements = new HBox(reviewerRequests);
        
        
        //Buttons to approve or deny Reviewer access
        Button yes = new Button("Yes");
        Button no = new Button("No");
        HBox buttons = new HBox(yes, no);
       
        
        top.setX(0); 
        //top.setY(0); 
        top.widthProperty().bind(scene.widthProperty()); 
        top.setHeight(75); 
        
        side.setY(0); 
        side.setWidth(200); 
        side.heightProperty().bind(scene.heightProperty());
    	
    	
    	// Load logo and font from StartCSE360
        ImageView iv = new ImageView(StartCSE360.w5);

        iv.setX(10);
        iv.setY(-3);
        iv.setFitWidth(75);
        iv.setFitHeight(75);
        
		//Font vr = new Font(20);
		Font vrs = StartCSE360.vrs;
		

		
		//Set up the reviewer requests list
		reviewerRequests.getItems().add("These Students have requested to become a Reviewer:\n");
		
		ArrayList<String> requesters = databaseHelper.getReviewerRequests();
		for (int i = 0; i < requesters.size(); ++i) {
			reviewerRequests.getItems().add(requesters.get(i));
		}
		
		//If one element has been clicked on
		reviewerRequests.setOnMouseClicked (a -> {
			String user = reviewerRequests.getSelectionModel().getSelectedItem();
			if (!user.equals("These Students have requested to become a Reviewer:\n")) {
				ArrayList<Answer> answers = databaseHelper.getAnswersbyUser(user);
				introduction.setText("Here are " + user + "'s most recently posted answers:");
				Label tenAnswers = new Label();
				String allAnswers = "";
				if (answers.size() <= 10) {
					for (int i = answers.size()-1; i >= 0; --i) {
						allAnswers += answers.get(i).getContents() + "\n\n";
					}
					tenAnswers.setText(allAnswers);
				} else {
					
				}
				
				 yes.setOnAction(b -> {
			        	String newRoles = databaseHelper.getUserRole(user).substring(0, 4);
			        	System.out.println(newRoles);
			        	newRoles += "1";
			        	System.out.println(newRoles);
			        	if (newRoles.length() == 5) {
			        	databaseHelper.updateRoles(user, newRoles);
			        	databaseHelper.deleteRequest(user);
			        	
						reviewerRequests.getItems().clear();
						ArrayList<String> newRequesters = databaseHelper.getReviewerRequests();
						reviewerRequests.getItems().add("These Students have requested to become a Reviewer:\n");
						for (int i = 0; i < newRequesters.size(); ++i) {
							reviewerRequests.getItems().add(newRequesters.get(i));
						}
			        	}
			     });
				 
				 no.setOnAction(b -> {
			        	databaseHelper.deleteRequest(user);
						
			        	reviewerRequests.getItems().clear();
						ArrayList<String> newRequesters = databaseHelper.getReviewerRequests();
						reviewerRequests.getItems().add("These Students have requested to become a Reviewer:\n");
						for (int i = 0; i < newRequesters.size(); ++i) {
							reviewerRequests.getItems().add(newRequesters.get(i));
						}
			     });
				
				requestInfo.getChildren().addAll(introduction, approvalQuestion, buttons, tenAnswers);
				reviewElements.getChildren().addAll(requestInfo);
			}
			
			
		});
		
				
	    
	    // label to display the welcome message for the user
        String username = StartCSE360.currentUser.GetUserName();
        //String roles = databaseHelper.getUserRole(username);
        String role = StartCSE360.currentUser.GetRole();
        User user = new User(username, "", role, "");
        String l = "Hello, " + username + "!\nYou're in instructor\nmode right now.";
	    Text label = new Text(l);
	    label.setFont(vrs);
        label.setFill(Color.WHITE);
	    
        Button backButton = new Button("Back");
        backButton.setFont(StartCSE360.vrs);
        backButton.setOnAction(a -> {
        	new WelcomeLoginPage(databaseHelper).show(primaryStage, user);
        });
        
        Button logoutButton = new Button("Logout");
        logoutButton.setFont(StartCSE360.vrs);
        logoutButton.setOnAction(a -> {
            new UserLoginPage(databaseHelper).show(primaryStage);
        });

	    rightSide.getChildren().addAll(label, logoutButton, backButton);
	    rightSide.setSpacing(10);
	    rightSide.setAlignment(Pos.TOP_CENTER);
	    StackPane sp = new StackPane(side, rightSide);
	    sp.setAlignment(Pos.TOP_RIGHT);
	    border.setTop(top);
	    border.setRight(sp);
	    border.setLeft(reviewElements);
	    
	    elements.getChildren().addAll(border, iv);
	    // Set the scene to primary stage
	    primaryStage.setScene(scene);
	    primaryStage.setTitle("Intructor Page");
	    primaryStage.show();
    	
    }
    
    
}