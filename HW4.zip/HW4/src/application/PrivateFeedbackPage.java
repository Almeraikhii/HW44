package application;

import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


import databasePart1.DatabaseHelper;
import QuestionAndAnswer.Answer;
import QuestionAndAnswer.AnswerList;
import Review.Review;

import java.util.ArrayList;






/**
 * Shows the private feedback messages sent to reviewers by the students.
 * This is only viewable by the Reviewers who wrote the original review
 * 
 * 
 */

public class PrivateFeedbackPage {
    public void show(Stage primaryStage, String username, int questionID, DatabaseHelper databaseHelper) {
        
    	
    	
    	VBox layout = new VBox();
        layout.getChildren().add(new Label("Private Feedbacks:"));

        AnswerList answerList = new AnswerList(databaseHelper);
        ArrayList<Answer> answers = answerList.getAnswersByQuestion(questionID);

        for (Answer answer : answers) {
            if (answer.getPrivate()) {
                
            	
                Review UsedReview = databaseHelper.getReviewByID(answer.getReviewID());

                if (UsedReview != null && username.equals(UsedReview.getUserName())) {
                    Label feedbackLabel = new Label(answer.getContents());
                    layout.getChildren().add(feedbackLabel);
                }
            }
        }

        Scene scene = new Scene(layout, 800, 400);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Private Feedback");
        primaryStage.show();
    }
}
