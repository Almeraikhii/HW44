package QuestionAndAnswer;

import java.sql.Timestamp;
import java.io.*;
import java.time.Duration;
import java.time.Instant;

/**
 * The Question class represents a single question, and contains
 * necessary information such as the question contents, the author,
 * and whether they wish to remain anonymous
 * 
 * @author Stavros Suppappola
 * @author Franz Benedict Villamin
 * @version 2.0.0, 3/20/2025
 */
public class Question implements Serializable{
	
	// Relevant data of a question
	private int id;
	private String title;
	private String contents;
	private String userName;
	private boolean anonymous;
	private Instant datePosted;
	private boolean edited;
	private Instant dateEdited;
	private boolean resolved;
	private int replies;
	
	/**
	 * Creates a <code>Question</code> object.
	 * 
	 * @param id the ID
	 * @param title the title
	 * @param contents the contents
	 * @param userName the userName of the poster
	 * @param anonymous true if the userName should be kept anonymous
	 * @param datePosted timestamp of when the <code>Question</code> was posted
	 * @param dateEdited timestamp of when the <code>Question</code> was edited
	 * @param edited true if the <code>Question</code> was edited
	 * @param resolved true if the <code>Question</code> was marked as resolved
	 * @param replies the number of replies to the question
	 */
	public Question (int id, String title, String contents, String userName, boolean anonymous, Timestamp datePosted,
					 Timestamp dateEdited, boolean edited, boolean resolved, int replies) {
		this.id = id;
		this.title = title;
		this.contents = contents;
		this.userName = userName;
		this.anonymous = anonymous;
		this.datePosted = datePosted.toInstant();
		if (dateEdited != null) {	
			this.dateEdited = dateEdited.toInstant();
		}
		else {
			this.dateEdited = null;
		}
		this.edited = edited;
		this.resolved = resolved;
		this.replies = replies;
	}
	
	/**
	 * Increments the number of replies.
	 */
	public void addReply() {
		replies++;
	}
	
	/**
	 * Gives the ID of a <code>Question</code>.
	 * @return the id
	 */
	public int getID() { return id; }
	
	/**
	 * Gives the title of a <code>Question</code>.
	 * @return the title
	 */
	public String getTitle() { return title; }
	
	/**
	 * Gives the contents of a <code>Question</code>.
	 * @return the contents
	 */
	public String getContents() { return contents; }
	
	/**
	 * Gives the resolved boolean of a <code>Question</code>.
	 * @return the resolved boolean
	 */
	public boolean getResolved() { return resolved; }
	
	/**
	 * Gives the number of replies of a <code>Question</code>.
	 * @return the number of replies
	 */
	public int getReplies() { return replies; }
	
	/**
	 * Gives the username of a <code>Question</code>.
	 * @return the username
	 */
	public String getUserName() { return userName; }
	
	/**
	 * Gives the anonymity of a <code>Question</code>
	 * @return the anonymous boolean
	 */
	public boolean getAnonymity() { return anonymous; }
	
	
	/**
	 * Determines how long ago a <code>Question</code> was posted.
	 * 
	 * @return a string describing how long ago
	 */
	public String getDatePosted() {
		Instant currentTime = Instant.now();
		String dateMessage = "";
		dateMessage += getTimeAgo(datePosted, currentTime);
		if(edited)
			dateMessage += " (Edited " + getTimeAgo(dateEdited, currentTime) + ")";
		return dateMessage;
	}
	
	private boolean isIssue;

	public boolean getIsIssue() {
	    return isIssue;
	}

	public void setIsIssue(boolean isIssue) {
	    this.isIssue = isIssue;
	}

	
	
	/**
	 * Helper method to see describe how long ago.
	 * 
	 * @param originalTime the timestamp of when this <code>Question</code> was posted
	 * @param currentTime the current time
	 * @return a String describing how long ago
	 * @see #getDatePosted()
	 */
	private String getTimeAgo(Instant originalTime, Instant currentTime) {
		double time = Duration.between(originalTime, currentTime).getSeconds();
		int seconds = (int)(time + 0.5);
		if(seconds < 60)
			return seconds + " second" + ((seconds == 1) ? "" : "s") + " ago";
		int minutes = (int)(time / 60 + 0.5);
		if(minutes < 60)
			return minutes + " minute" + ((minutes == 1) ? "" : "s") + " ago";
		int hours = (int)(time / 3600 + 0.5);
		if(hours < 24)
			return hours + " hour" + ((hours == 1) ? "" : "s") + " ago";
		int days = (int)(time / 86400 + 0.5);
		if(days < 7)
			return days + " day" + ((days == 1) ? "" : "s") + " ago";
		int weeks = (int)(time / 604800 + 0.5);
		if(days < 52)
			return weeks + " week" + ((weeks == 1) ? "" : "s") + " ago";
		int years = (int)(time / 31536000 + 0.5);
		return years + " year" + ((years == 1) ? "" : "s") + " ago";
	}
	

	/**
	 * Turns the <code>Question</code> into a short readable text.
	 * 
	 * @return the string of the <code>Question</code>
	 */
	public String toShortString() {
		String data;
		data = String.format("%s - %s\nPosted by %s %s\nReplies: %d Post ID: %d", title, (resolved ? "Resolved" : "Unresolved"), (anonymous ? "Anonymous" : userName), getDatePosted(), replies, id);
		return data;
	}
	
	/**
	 * Turns the <code>Question</code> into readable text.
	 * 
	 * @return the string of the <code>Question</code>
	 */
	public String toString() {
		String data;
		data = String.format("%s - %s\nPosted by %s %s\n%s\nReplies: %d Post ID: %d", title, (resolved ? "Resolved" : "Unresolved"), (anonymous ? "Anonymous" : userName), getDatePosted(), contents, replies, id);
		return data;
	}
}
