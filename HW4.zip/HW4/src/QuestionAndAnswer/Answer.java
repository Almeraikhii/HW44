package QuestionAndAnswer;

import java.time.Instant;
import java.io.*;
import java.sql.Timestamp;
import java.time.Duration;

/**
 * The Answer class represents a single answer, and contains
 * necessary information such as the answer contents, the author,
 * and whether they wish to remain anonymous
 * 
 * @author Stavros Suppappola
 * @author Franz Benedict Villamin
 * @version 2.0.0, 3/2025
 */
public class Answer {
	
	// Relevant data of a answer
	private int id;
	private int questionID;
	// The answer ID should be -1 if the answer is replying to a question.
	// Otherwise, it should be the ID of the answer it is replying to.
	private int answerID;
	private int reviewID;
	private String contents;
	private String userName;
	private boolean anonymous;
	private Instant datePosted;
	private boolean edited;
	private Instant dateEdited;
	private boolean resolved;
	private boolean isPrivate;
	
	/**
	 * Constructor which allows for the creation of an answer object. This should only be called by <code>AnswerList</code>.
	 * @param id the ID number of the <code>Answer</code>
	 * @param questionID the ID number of the <code>Question</code> being replied to
	 * @param answerID the ID number of the <code>Answer</code> being replied to, is -1 if not a reply to an answer
	 * @param reviewID the ID number of the <code>Review</code> being replied to, is -1 if not a reply to a review
	 * @param contents the contents of the <code>Answer</code>
	 * @param userName the username of the poster
	 * @param anonymous whether the poster wishes to be anonymous
	 * @param datePosted the date the <code>Answer</code> was posted 
	 * @param edited whether the <code>Answer</code> was edited
	 * @param dateEdited the date the <code>Answer</code> was edited
	 * @param resolved if the <code>Answer</code> resolves a question
	 * @param isPrivate if the <code>Answer</code> is a private message
	 * @see AnswerList
	 * @see Question
	 */
	public Answer (int id, int questionID, int answerID, int reviewID, String contents, String userName, boolean anonymous, Timestamp datePosted, boolean edited, Timestamp dateEdited, boolean resolved, boolean isPrivate) {
		this.id = id;
		this.questionID = questionID;
		this.answerID = answerID;
		this.reviewID = reviewID;
		this.contents = contents;
		this.userName = userName;
		this.anonymous = anonymous;
		this.edited = edited;
		this.isPrivate = isPrivate;
		this.resolved = resolved;
		this.datePosted = datePosted.toInstant();
		if (dateEdited != null) {	
			this.dateEdited = dateEdited.toInstant();
		}
		else {
			this.dateEdited = null;
		}

	}
	
	/**
	 * Returns the ID number of the <code>Answer</code>.
	 * @return the ID number
	 */
	public int getID() { return id; }
	
	/**
	 * Returns the contents of the <code>Answer</code>.
	 * @return the contents as a string
	 */
	public String getContents() { return contents; }
	
	/**
	 * Returns the resolved state of the <code>Answer</code>.
	 * @return the resolved state as a boolean
	 */
	public boolean getResolved() { return resolved; }
	
	/**
	 * Returns the private state of the <code>Answer</code>.
	 * @return the private state as a boolean
	 */
	public boolean getPrivate() { return isPrivate; }
		
	/**
	 * Returns the username  of the <code>Answer</code>.
	 * @return the uesrname as a string
	 */
	public String getUserName() { return userName; }
	
	/**
	 * Returns the anonymity state of the <code>Answer</code>.
	 * @return the anonymity state as a boolean
	 */
	public boolean getAnonymity() { return anonymous; }
	
	/**
	 * Returns the question ID number of the <code>Answer</code>.
	 * @return the question ID as an int
	 */
	public int getQuestionID() { return questionID; }
	
	/**
	 * Returns the answer ID number of the <code>Answer</code>.
	 * @return the answer ID as an int
	 */
	public int getAnswerID() { return answerID; }
	
	
	/**
	 * Determines how long ago an <code>Answer</code> was posted, including if it was edited.
	 * @return a string describing how long ago the <code>Answer</code> was posted
	 */
	public String getDatePosted() {
		Instant currentTime = Instant.now();
		String dateMessage = "";
		dateMessage += getTimeAgo(datePosted, currentTime);
		if(edited)
			dateMessage += " (Edited " + getTimeAgo(dateEdited, currentTime) + ")";
		return dateMessage;
	}
	
	/**
	 * Helper method to determine how long ago an <code>Answer</code> was posted.
	 * @param originalTime the original time of posting/editing
	 * @param currentTime the current time
	 * @return a string describing how long ago
	 */
	private String getTimeAgo(Instant originalTime, Instant currentTime) {
		double time = Duration.between(originalTime, currentTime).getSeconds();
		int seconds = (int)(time + 0.5);
		if(seconds < 60)
			return seconds + " second" + ((seconds == 1) ? "" : "s") + " ago";
		int minutes = (int)(time / 60 + 0.5);
		if(minutes < 60)
			return minutes + " minute" + ((minutes == 1) ? "" : "s") + " ago";
		int hours = (int)(time / 3600 + 0.5);
		if(hours < 24)
			return hours + " hour" + ((hours == 1) ? "" : "s") + " ago";
		int days = (int)(time / 86400 + 0.5);
		if(days < 7)
			return days + " day" + ((days == 1) ? "" : "s") + " ago";
		int weeks = (int)(time / 604800 + 0.5);
		if(days < 52)
			return weeks + " week" + ((weeks == 1) ? "" : "s") + " ago";
		int years = (int)(time / 31536000 + 0.5);
		return years + " year" + ((years == 1) ? "" : "s") + " ago";
	}

public int getReviewID() {
	    return reviewID;
	}
	
	
	/**
	 * Prints the data of an <code>Answer</code> in a readable format.
	 * @return a string containing information about the <code>Answer</code>.
	 * @deprecated use other grabber methods to get the information
	 */
	public String toString() {
		String data;
		data = String.format("%s%s\nPosted by %s %s Reply ID: %d", (resolved ? "**Helpful Answer**\n" : ""), contents, getUserName(), getDatePosted(), id);
		return data;
	}
}
