package QuestionAndAnswer;

import java.util.ArrayList;
import databasePart1.DatabaseHelper;

/**
 * Allows for the posting, editing, deleting, and getting of <code>Questions</code>.
 * <p>
 * There is input validation for each method to ensure that only certain users may do certain operations.
 * @author Stavros Suppappola
 * @author Franz Benedict Villamin
 * @version 2.0.0, 3/20/2025
 */
public class QuestionList {
	
	private static DatabaseHelper databaseHelper;
	private ArrayList<Question> questionList;
	
	/**
	 * Connects to the database.
	 * 
	 * @see databasePart1.DatabaseHelper
	 */
	public QuestionList(DatabaseHelper databaseHelper){
		this.databaseHelper = databaseHelper;
		this.questionList = new ArrayList<Question>();		
	}
	
	/**
	 * Searches for <code>Questions</code> with similar keywords.
	 * 
	 * @param userSearch the keywords to be searched for
	 * @return ArrayList of similar questions
	 * @see QuestionAndAnswer.Question
	 * @see QuestionAndAnswer.QuestionSearcher#finding_Keyword(String)
	 */
	public ArrayList<Question> searching_questions(String userSearch) {
    		String keyword = QuestionSearcher.finding_Keyword(userSearch);

   		 if (keyword == null) {
        		return null;
    }

    		ArrayList<Question> similar_questions = new ArrayList<>();

    		for (Question current_question : getAllQuestions()) {
        	if (current_question.getTitle().toLowerCase().contains(keyword.toLowerCase()) ||
            current_question.getContents().toLowerCase().contains(keyword.toLowerCase())) {
            similar_questions.add(current_question);
        }
    }

    return similar_questions;
}

	
	/**
	 * Gets a specific <code>Question</code> by ID number.
	 * 
	 * @param id the ID to be searched for
	 * @return a <code>Question</code> object specified
	 * @see QuestionAndAnswer.Question
	 * @see databasePart1.DatabaseHelper
	 */
	public Question getQuestion(int id) {
		return databaseHelper.getQuestionByID(id);
	}
	
	/**
	 * Gets all <code>Questions</code>.
	 * 
	 * @return an ArrayList of all <code>Questions</code>
	 * @see QuestionAndAnswer.Question
	 * @see databasePart1.DatabaseHelper
	 */
	public ArrayList<Question> getAllQuestions() {
		questionList = databaseHelper.loadQuestions();
		return questionList;
	}
	
	/**
	 * Gets <code>Questions</code> that contains reviews from a specific reviewer.
	 * 
	 * @param userName the userName of the reviewer
	 * @return an ArrayList of  <code>Questions</code>
	 * @see QuestionAndAnswer.Question
	 * @see databasePart1.DatabaseHelper
	 */
	public ArrayList<Question> getQuestionsByReviewer(String userName){
		questionList = databaseHelper.getQuestionByReviewer(userName);
		return questionList;
	}
	
	/**
	 * Gets all <code>Questions</code> from a specific user.
	 * 
	 * @param userName the userName to be searched for
	 * @return an ArrayList of all <code>Questions</code>
	 * @see QuestionAndAnswer.Question
	 * @see databasePart1.DatabaseHelper
	 */
	public ArrayList<Question> getAllQuestionsByUser(String userName) {
		questionList = databaseHelper.getQuestionsByUser(userName);
		return questionList;
	}
	
	/**
	 * Gets all unresolved <code>Questions</code> from a specific user.
	 * 
	 * @param userName the userName to be searched for
	 * @return an ArrayList of all <code>Questions</code>
	 * @see QuestionAndAnswer.Question
	 * @see databasePart1.DatabaseHelper
	 */
	public ArrayList<Question> getUnresolvedQuestionsByUser(String userName) {
		questionList = databaseHelper.getQuestionsByUser(userName);
		ArrayList<Question> subsetList = new ArrayList<Question>();
		for(Question question : questionList)
		{
			if(!question.getResolved())
				subsetList.add(question);
		}
		return subsetList;
	}
	
	/**
	 * Gets all unresolved <code>Questions</code>.
	 * 
	 * @return an ArrayList of all <code>Questions</code>
	 * @see QuestionAndAnswer.Question
	 * @see databasePart1.DatabaseHelper
	 */
	public ArrayList<Question> getUnresolvedQuestions() {
		questionList = databaseHelper.loadQuestions();
		ArrayList<Question> subsetList = new ArrayList<Question>();
		for(Question question : questionList)
		{
			if(!question.getResolved())
				subsetList.add(question);
		}
		return subsetList;
	}
	
	/**
	 * Checks a <code>Question</code> and if valid, adds it to the database.
	 * 
	 * The title must be at least 10 and at most 200 characters. The contents must be at least 10 and at most 5000 characters.
	 * 
	 * @param title the title of the <code>Quesiton</code>
	 * @param contents the contents of the <code>Quesiton</code>
	 * @param userName the username of the poster
	 * @param anonymous whether the user wants to stay anonymous, true = yes
	 * @return a boolean where true indicates the <code>Quesiton</code> was successfully posted
	 * @see databasePart1.DatabaseHelper
	 */
	public boolean addQuestion(String title, String contents, String userName, boolean anonymous) {
		if(title.length() < 10) {
			System.out.println("Error! Title must be at least 10 characters.");
			return false;
		}
		else if(title.length() > 200) {
			System.out.println("Error! Title must be no more than 200 characters.");
			return false;
		}
		else if(contents.length() < 10) {
			System.out.println("Error! Contents must be at least 10 characters.");
			return false;
		}
		else if(contents.length() > 5000) {
			System.out.println("Error! Contents must be no more than 5000 characters.");
			return false;
		}
		databaseHelper.postQuestion(userName, title, contents, anonymous);
		return true;
	}
	
	/**
	 * Checks a <code>Quesiton</code> and if valid, edits the <code>Quesiton</code>.
	 * 
	 * The title must be at least 10 and at most 200 characters. The contents must be at least 10 and at most 5000 characters.
	 * The userName of the editor must be the same as the poster.
	 * 
	 * @param id the ID of the <code>Quesiton</code> to be edited
	 * @param title the new title
	 * @param contents the new contents
	 * @param anonymity the new anonymity value
	 * @param userName the userName of the editor
	 * @return a boolean where true indicates the <code>Quesiton</code> was successfully edited
	 * @see databasePart1.DatabaseHelper
	 * @see QuestionAndAnswer.Question
	 */
	public boolean editQuestion(int id, String title, String contents, boolean anonymity, String userName) {
		if(title.length() < 10) {
			System.out.println("Error! Title must be at least 10 characters.");
			return false;
		}
		else if(title.length() > 200) {
			System.out.println("Error! Title must be no more than 200 characters.");
			return false;
		}
		if(contents.length() < 10) {
			System.out.println("Error! Contents must be at least 10 characters.");
			return false;
		}
		else if(contents.length() > 5000) {
			System.out.println("Error! Contents must be no more than 5000 characters.");
			return false;
		}
		Question toBeEdited = databaseHelper.getQuestionByID(id);
		// if username does not match creator
		if(!toBeEdited.getUserName().equals(userName))
		{
			System.out.println("Error! You are not authorized to edit this question!");
			return false;
		}
		databaseHelper.editQuestion(title, contents, anonymity, id);;
		return true;
	}
	
	/**
	 * Deletes a <code>Question</code> from the database, only if the deleter was the one who posted.
	 * 
	 * @param id the ID of the <code>Question</code> to be deleted
	 * @param userName the username of the deleter
	 * @return a boolean where true indicates the <code>Question</code> was successfully deleted
	 * @see databasePart1.DatabaseHelper
	 * @see QuestionAndAnswer.Question
	 */
	public boolean deleteQuestion(int id, String userName) {
		Question toBeEdited = databaseHelper.getQuestionByID(id);
		// if username does not match creator
		if(!toBeEdited.getUserName().equals(userName))
		{
			System.out.println("Error! You are not authorized to delete this question!");
			return false;
		}
		databaseHelper.deleteQuestion(id);
		return true;
	}
	
	/**
	 * Marks a <code>Question</code> as resolved.
	 * 
	 * The question can only be marked as resolved by the poster.
	 * 
	 * @param id the ID of the <code>Question</code> to be marked resolved.
	 * @param userName the userName of the resolver
	 * @return a boolean where true indicates the <code>Question</code> was successfully resolved
	 * @see databasePart1.DatabaseHelper
	 * @see QuestionAndAnswer.Question
	 */
	public boolean markResolved(int id, String userName) {
		Question toBeEdited = databaseHelper.getQuestionByID(id);
		// if username does not match creator
		if(!toBeEdited.getUserName().equals(userName))
		{
			System.out.println("Error! You are not authorized to resolve this question!");
			return false;
		}
		if(!toBeEdited.getResolved())
			databaseHelper.resolveQuestion(id);
		return true;
	}

}
