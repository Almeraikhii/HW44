package QuestionAndAnswer;

import java.util.ArrayList;
import databasePart1.DatabaseHelper;

/**
 * Allows for the posting, editing, deleting, and getting of <code>Answers</code>.
 * <p>
 * There is input validation for each method to ensure that only certain users may do certain operations.
 * @author Stavros Suppappola
 * @author Franz Benedict Villamin
 * @version 1.0.0, 3/29/2025
 */
public class AnswerList {
	
	private static DatabaseHelper databaseHelper;
	private ArrayList<Answer> answerList;
	
	/**
	 * Gives the list access to the database.
	 * @param databaseHelper the database object
	 * @see databasePart1.DatabaseHelper
	 */
	public AnswerList(DatabaseHelper databaseHelper){
		this.databaseHelper = databaseHelper;
		this.answerList = new ArrayList<Answer>();
	}
	
	/**
	 * Gives all <code>Answers</code> to a specific <code>Question</code>.
	 * @param id the ID of the <code>Question</code>
	 * @return an ArrayList of all <code>Answers</code> to a <code>Question</code>
	 * @see Answer
	 * @see Question
	 */
	public ArrayList<Answer> getAnswersByQuestion(int id) {
		answerList = databaseHelper.getAnswerByQuestion(id);
		return answerList;
	}
	
	/**
	 * Gives all <code>Answers</code> to a specific <code>Review</code>.
	 * @param id the ID of the <code>Review</code>
	 * @return an ArrayList of all <code>Answers</code> to a <code>Review</code>
	 * @see Answer
	 * @see Review.Review
	 */
	public ArrayList<Answer> getAnswersByReview(int id) {
		answerList = databaseHelper.getAnswerByReview(id);
		return answerList;
	}
	
	/**
	 * Adds an <code>Answer</code> to the list and stores it. There is input validation to ensure proper posting.
	 * @param questionID the ID of the <code>Question</code> being replied to
	 * @param answerID the ID of the <code>Answer</code> being replied to, -1 if none
	 * @param reviewID the ID of the <code>Review</code> being replied to, -1 if none
	 * @param contents the contents of the <code>Answer</code>
	 * @param userName the username of the poster
	 * @param anonymous whether the poster wants to remain anonymous
	 * @param isPrivate whether the answer is a private message
	 * @return a boolean whether the answer was posted or not
	 * @see Answer
	 * @see Question
	 * @see Review.Review
	 */
	public static boolean addAnswer(int questionID, int answerID, int reviewID, String contents, String userName, boolean anonymous, boolean isPrivate) {
		if(contents.length() < 10) {
			System.out.println("Error! Contents must be at least 10 characters.");
			return false;
		}
		else if(contents.length() > 5000) {
			System.out.println("Error! Contents must be no more than 5000 characters.");
			return false;
		}
		databaseHelper.postAnswer(questionID, answerID, reviewID, userName, contents, anonymous, isPrivate);
		return true;
	}
	
	/**
	 * This function edits a specific answer
	 * @param id
	 * @param contents the new contents of the <code>Answer</code>
	 * @param anonymity the anonymity value of the <code>Answer</code>
	 * @param userName the userName of the editor
	 * @return true if edited, false if error
	 * @see Answer
	 */
	public boolean editAnswer(int id, String contents, boolean anonymity, String userName) {
		if(contents.length() < 10) {
			System.out.println("Error! Contents must be at least 10 characters.");
			return false;
		}
		else if(contents.length() > 5000) {
			System.out.println("Error! Contents must be no more than 5000 characters.");
			return false;
		}
		Answer toBeEdited = databaseHelper.getAnswerByID(id);
		// if username does not match creator
		if(!toBeEdited.getUserName().equals(userName))
		{
			System.out.println("Error! You are not authorized to edit this answer!");
			return false;
		}
		databaseHelper.editAnswer(contents, anonymity, id);
		return true;
	}
	
	/**
	 * deletes an <code>Answer</code> from the list
	 * @param id the ID number of the <code>Answer</code>
	 * @param userName the userName of the deleter
	 * @return true if deleted, false if there is an error
	 * @see Answer
	 */
	public boolean deleteAnswer(int id, String userName) {
		Answer toBeEdited = databaseHelper.getAnswerByID(id);
		// if username does not match creator
		if(!toBeEdited.getUserName().equals(userName))
		{
			System.out.println("Error! You are not authorized to delete this answer!");
			return false;
		}
		databaseHelper.deleteAnswer(id);
		return true;
	}
	
	/**
	 * marks an <code>Answer</code> as resolved if an <code>Answer</code> was marked as helpful. Also marks the <code>Question</code> as resolved.
	 * @param id the ID number of the <code>Answer</code>
	 * @param userName the userName of the marker
	 * @return a boolean, true if resolved
	 * @see Answer
	 * @see Question
	 */
	public boolean markResolved(int id, String userName) {
		Answer toBeEdited = databaseHelper.getAnswerByID(id);
		Question question = databaseHelper.getQuestionByID(toBeEdited.getQuestionID());
		// if answer does not match creator
		if(!question.getUserName().equals(userName))
		{
			System.out.println("Error! You are not authorized to resolve this answer!");
			return false;
		}
		if(!toBeEdited.getResolved())
		{
			databaseHelper.resolveAnswer(id);
			databaseHelper.resolveQuestion(toBeEdited.getQuestionID());
		}
		return true;
	}
}
