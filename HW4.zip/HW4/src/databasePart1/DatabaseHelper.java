package databasePart1;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import QuestionAndAnswer.*;
import Review.Review;
import application.User;


/**
 * The DatabaseHelper class is responsible for managing the connection to the database,
 * performing operations such as user registration, login validation, and handling invitation codes.
 * @author Professor
 * @author Franz Benedict Villamin
 * @author Kirsten Buelt
 * @author Stavros Suppappola
 * @version 3.0.0, 4/1/2025
 */
public class DatabaseHelper {

	// JDBC driver name and database URL 
	static final String JDBC_DRIVER = "org.h2.Driver";   
	static final String DB_URL = "jdbc:h2:~/FoundationDatabase";  

	//  Database credentials 
	static final String USER = "sa"; 
	static final String PASS = ""; 

	private Connection connection = null;
	private Statement statement = null; 
	//	PreparedStatement pstmt

	/**
	 * Connects to the database.
	 * @throws SQLException
	 */
	public void connectToDatabase() throws SQLException {
		try {
			Class.forName(JDBC_DRIVER); // Load the JDBC driver
			System.out.println("Connecting to database...");
			connection = DriverManager.getConnection(DB_URL, USER, PASS);
			statement = connection.createStatement(); 
			// You can use this command to clear the database and restart from fresh.
			//statement.execute("DROP ALL OBJECTS");

			createTables();  // Create the necessary tables if they don't exist
		} catch (ClassNotFoundException e) {
			System.err.println("JDBC Driver not found: " + e.getMessage());
		}
	}

	/**
	 * Creates the database tables.
	 * @throws SQLException
	 */
	private void createTables() throws SQLException {
		String userTable = "CREATE TABLE IF NOT EXISTS cse360users ("
				+ "id INT AUTO_INCREMENT PRIMARY KEY, "
				+ "userName VARCHAR(255) UNIQUE, "
				+ "password VARCHAR(255), "
				+ "roles VARCHAR(5), "
				+ "email VARCHAR(255))";
		statement.execute(userTable);
		
		// Create the invitation codes table
	    String invitationCodesTable = "CREATE TABLE IF NOT EXISTS InvitationCodes ("
	            + "code VARCHAR(10) PRIMARY KEY, "
	            + "isUsed BOOLEAN DEFAULT FALSE, "
	            + "dateCreated VARCHAR(50))"; // Change -- added a timestamp to invitation codes	
	    statement.execute(invitationCodesTable);
	    
	    String OTPCodesTable = "CREATE TABLE IF NOT EXISTS OTPCodes ("
	    		+ "code VARCHAR(16) PRIMARY KEY, "
	    		+ "userName VARCHAR(255) UNIQUE)";
	    statement.execute(OTPCodesTable);
	    
	    String questionsTable = "CREATE TABLE IF NOT EXISTS Questions ("
	    		+ "id INT AUTO_INCREMENT PRIMARY KEY, "
	    		+ "userName VARCHAR(20), "
	    		+ "title VARCHAR(201) UNIQUE, "
	    		+ "contents VARCHAR(5001), "
	    		+ "datePosted TIMESTAMP DEFAULT CURRENT_TIMESTAMP, "
	    		+ "dateEdited TIMESTAMP NULL DEFAULT NULL, "
	    		+ "edited BOOLEAN DEFAULT FALSE, "
	    		+ "anonymous BOOLEAN DEFAULT FALSE, "
	    		+ "resolved BOOLEAN DEFAULT FALSE)";
	    statement.execute(questionsTable);
	    
	    String answersTable = "CREATE TABLE IF NOT EXISTS Answers ("
	    		+ "id INT AUTO_INCREMENT PRIMARY KEY, "
	    		+ "questionID INT, "
	    		+ "answerID INT,"
	    		+ "reviewID INT,"
	    		+ "userName VARCHAR(20), "
	    		+ "contents VARCHAR(5001), "
	    		+ "datePosted TIMESTAMP DEFAULT CURRENT_TIMESTAMP, "
	    		+ "dateEdited TIMESTAMP NULL DEFAULT NULL, "
	    		+ "edited BOOLEAN DEFAULT FALSE, "
	    		+ "anonymous BOOLEAN DEFAULT FALSE, "
	    		+ "private BOOLEAN DEFAULT FALSE, "
	    		+ "resolved BOOLEAN DEFAULT FALSE)";
	    statement.execute(answersTable);
	    
	    String reviewsTable = "CREATE TABLE IF NOT EXISTS Reviews ("
	    		+ "id INT AUTO_INCREMENT PRIMARY KEY, "
	    		+ "questionID INT, "
	    		+ "answerID INT, "
	    		+ "userName VARCHAR(20), "
	    		+ "contents VARCHAR(5001), "
	    		+ "datePosted TIMESTAMP DEFAULT CURRENT_TIMESTAMP, "
	    		+ "dateEdited TIMESTAMP NULL DEFAULT NULL, "
	    		+ "edited BOOLEAN DEFAULT FALSE)";
	    statement.execute(reviewsTable);
	    
	    String trustedReviewersTable = "CREATE TABLE IF NOT EXISTS TrustedReviewers ("
	    		+ "studentName VARCHAR(20), "
	    		+ "reviewerName VARCHAR(20), "
	    		+ "reviewerWeight INT)";
	    statement.execute(trustedReviewersTable);
	    
	    String reviewerRequestsTable = "CREATE TABLE IF NOT EXISTS ReviewerRequests ("
	    		+ "username VARCHAR(20))";
	    statement.execute(reviewerRequestsTable);
	}


	/**
	 * Check if the database is empty
	 * @return true if empty
	 * @throws SQLException
	 */
	public boolean isDatabaseEmpty() throws SQLException {
		String query = "SELECT COUNT(*) AS count FROM cse360users";
		ResultSet resultSet = statement.executeQuery(query);
		if (resultSet.next()) {
			return resultSet.getInt("count") == 0;
		}
		return true;
	}

	/**
	 * Registers a new user in the database.
	 * @param user the userName
	 * @throws SQLException
	 */
	public void register(User user) throws SQLException {
		String insertUser = "INSERT INTO cse360users (userName, password, email, roles) VALUES (?, ?, ?, ?)";
		try (PreparedStatement pstmt = connection.prepareStatement(insertUser)) {
			pstmt.setString(1, user.getUserName());
			pstmt.setString(2, user.getPassword());
			pstmt.setString(4, user.getRole());
			pstmt.setString(3, user.getEmail());
			pstmt.executeUpdate();
		}
	}

	/**
	 * Validates a user's login credentials.
	 * @param user the user
	 * @return true if valid
	 * @throws SQLException
	 */
	public boolean login(User user) throws SQLException {
		String query = "SELECT * FROM cse360users WHERE userName = ? AND password = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, user.getUserName());
			pstmt.setString(2, user.getPassword());
			try (ResultSet rs = pstmt.executeQuery()) {
				return rs.next();
			}
		}
	}
	
	public boolean OTPlogin (String user, String code) throws SQLException {
		String query = "SELECT * FROM OTPCodes WHERE userName = ? AND code = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, user);
			pstmt.setString(2, code);
			try (ResultSet rs = pstmt.executeQuery()) {
				return rs.next();
			}
		}
	}
	
	/**
	 * Deletes a OTP code
	 * @param user the user
	 * @param code the code
	 * @return true if deleted
	 * @throws SQLException
	 */
	public boolean deleteOTP(String user, String code) throws SQLException {
	    String query = "DELETE FROM OTPCodes WHERE userName = ? AND code = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, user);
	        pstmt.setString(2, code);
	        int result = pstmt.executeUpdate();
			if(result >= 1) {
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	/**
	 * Checks if a user already exists in the database based on their userName.
	 * @param userName the user
	 * @return true if they exist
	 */
	public boolean doesUserExist(String userName) {
	    String query = "SELECT COUNT(*) FROM cse360users WHERE userName = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        
	        pstmt.setString(1, userName);
	        ResultSet rs = pstmt.executeQuery();
	        
	        if (rs.next()) {
	            // If the count is greater than 0, the user exists
	            return rs.getInt(1) > 0;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return false; // If an error occurs, assume user doesn't exist
	}
	
	/**
	 * Retrieves the role of a user from the database using their UserName.
	 * @param userName the user
	 * @return the roles of the user
	 */
	public String getUserRole(String userName) {
	    String query = "SELECT roles FROM cse360users WHERE userName = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, userName);
	        ResultSet rs = pstmt.executeQuery();
	        
	        if (rs.next()) {
	            return rs.getString("roles"); // Return the role if user exists
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return null; // If no user exists or an error occurs
	}
	
	/**
	 * Updates the roles of a user.
	 * @param username the user to be updated
	 * @param roles the new roles
	 * @return true if success
	 */
	public boolean updateRoles(String username, String roles) {
		String query = "UPDATE cse360users SET roles = ? WHERE userName = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, roles);
			pstmt.setString(2, username);
			int result = pstmt.executeUpdate();
			if(result > 0) {
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	/**
	 * Generates a new invitation code and inserts it into the database.
	 * @return the invitation code
	 */
	public String generateInvitationCode() {
	    String code = UUID.randomUUID().toString().substring(0, 4); // Generate a random 4-character code
	    String query = "INSERT INTO InvitationCodes (code, dateCreated) VALUES (?, CURRENT_TIMESTAMP)"; // Change -- adds the current timestamp to the invitation code

	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, code);
	        pstmt.executeUpdate();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return code;
	}
	
	/**
	 * Validates an invitation code to check if it is unused.
	 * @param code the code
	 * @return boolean if code is valid
	 */
	public boolean validateInvitationCode(String code) {
	    String query = "SELECT * FROM InvitationCodes WHERE code = ? AND isUsed = FALSE";
	    // change -- new query to get the current time
	    String query2 = "SELECT CURRENT_TIMESTAMP AS currentTime";
	    try (PreparedStatement pstmt = connection.prepareStatement(query); PreparedStatement pstmt2 = connection.prepareStatement(query2)) {
	        pstmt.setString(1, code);
	        ResultSet rs = pstmt.executeQuery();
	        ResultSet rs2 = pstmt2.executeQuery();
	        if (rs.next() && rs2.next()) {
	            // Mark the code as used
	            markInvitationCodeAsUsed(code);
	        	
	            // Change -- compare the times, if more than 30seconds (can change, do not accept invite code)
	        	Timestamp dateCreated = rs.getTimestamp("dateCreated");
	        	Timestamp currentTime = rs2.getTimestamp("currentTime");
	        	if(currentTime.getTime() - dateCreated.getTime() >= 300000) {
	        		return false;
	        	}
	            return true;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return false;
	}
	
	/**
	 * Marks the invitation code as used in the database.
	 * @param code the new code to be used
	 */
	private void markInvitationCodeAsUsed(String code) {
	    String query = "UPDATE InvitationCodes SET isUsed = TRUE WHERE code = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, code);
	        pstmt.executeUpdate();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
	
	/**
	 * Generates a one time password.
	 * @param username the uername of the user
	 * @return the string of the OTP code
	 */
	public String generateOTPCode(String username) {
		String code = UUID.randomUUID().toString().substring(0,8);
		String query = "INSERT INTO OTPCodes (code, userName) VALUES (?, ?)";
		
		try (PreparedStatement pstmt = connection.prepareStatement(query)){
			pstmt.setString(1, code);
			pstmt.setString(2, username);
	        pstmt.executeUpdate();
		} catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return code;
		
	}
	
	/**
	 * Checks for a user and deltes them.
	 * @param userName the userName of the user to be deleted
	 * @return true if deleted
	 */
	public boolean deleteUser(String userName) {
		String query = "DELETE FROM cse360users WHERE userName = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, userName);
			int result = pstmt.executeUpdate();
			if(result >= 1) {
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	/**
	 * Changes a users password.
	 * @param user the userName of the user
	 * @param password the new password
	 * @return a boolean where true indicates success
	 */
	public boolean changePassword(String user, String password) {
		String query = "UPDATE cse360users SET password = ? WHERE userName = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, password);
			pstmt.setString(2, user);
			int result = pstmt.executeUpdate();
			if(result > 0) {
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	/**
	 * Lists all users.
	 * @return string containing all users
	 * @throws SQLException
	 */
	public String listUsers() throws SQLException {
        String usernames = "";
        String query = "SELECT userName FROM cse360users";

        try (PreparedStatement pstmt = connection.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {
            
            while (rs.next()) {
                usernames = usernames + rs.getString("userName") + "\n";
            }
        }
        return usernames;
    }
	
	//Functions for Student Page
	
	
	/**
	 * Posts a <code>Question</code> to the database. Should only be called by <code>QuestionList</code>.
	 * @param userName the userName of the poster
	 * @param title the title
	 * @param contents the contents
	 * @param isAnonymous the anonymity value
	 * @see QuestionAndAnswer.Question
	 * @see QuestionAndAnswer.QuestionList#addQuestion(String, String, String, boolean)
	 */
	public void postQuestion(String userName, String title, String contents, boolean isAnonymous){
		String query = "INSERT INTO Questions (userName, title, contents, anonymous) VALUES (?, ?, ?, ?)";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, userName);
			pstmt.setString(2, title);
			pstmt.setString(3, contents);
			pstmt.setBoolean(4,  isAnonymous);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Posts an <code>Answer</code> to the database. Should only be called by <code>AnswerList</code>
	 * @param questionID the ID of the <code>Question</code> being replied to
	 * @param answerID the ID of the <code>Answer</code> being replied to, -1 if none
	 * @param reviewID the ID of the <code>Review</code> being replied to, -1 if none
	 * @param contents the contents of the <code>Answer</code>
	 * @param userName the username of the poster
	 * @param isAnonymous whether the poster wants to remain anonymous
	 * @param isPrivate whether the answer is a private message
	 * @see QuestionAndAnswer.Answer
	 * @see QuestionAndAnswer.AnswerList#addAnswer(int, int, int, String, String, boolean, boolean)
	 */
	public void postAnswer(int questionID, int answerID, int reviewID, String userName, String contents, boolean isAnonymous, boolean isPrivate) {
		String query = "INSERT INTO Answers (questionID, answerID, reviewID, userName, contents, anonymous, private) VALUES (?, ?, ?, ?, ?, ?, ?)";
		try(PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setInt(1, questionID);
			pstmt.setInt(2, answerID);
			pstmt.setInt(3, reviewID);
			pstmt.setString(4, userName);
			pstmt.setString(5, contents);
			pstmt.setBoolean(6, isAnonymous);
			pstmt.setBoolean(7, isPrivate);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Posts a <code>Review</code> to the database. Should only be called by <code>ReviewList</code>.
	 * 
	 * @param questionID the ID of the <code>Question</code> the answer being reviewed is answering
	 * @param answerID the ID of the <code>Answer</code> being reviewed
	 * @param userName the userName of the poster
	 * @param contents the contents of the <code>Review</code>
	 * @see Review.Review
	 * @see Review.ReviewList#addReview(int, int, String, String)
	 */
	public void postReview(int questionID, int answerID, String userName, String contents)
	{
		String query = "INSERT INTO Reviews (questionID, answerID, userName, contents) VALUES (?, ?, ?, ?)";
		try(PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setInt(1, questionID);
			pstmt.setInt(2, answerID);
			pstmt.setString(3, userName);
			pstmt.setString(4, contents);
			pstmt.executeUpdate();
		} catch (SQLException e)
		{
			e.printStackTrace();
		}
	}
	
	/**
	 * Edits an <code>Question</code> in the database. Should only be called by <code>QuestionList</code>
	 * @param title the new title
	 * @param contents the new contents of the <code>Question</code>
	 * @param anonymity the new anonymity
	 * @param id the ID of the <code>Question</code>
	 * @see QuestionAndAnswer.Question
	 * @see QuestionAndAnswer.QuestionList#editQuestion(int, String, String, boolean, String)
	 */
	public void editQuestion(String title, String contents, boolean anonymity, int id) {
		String query = "UPDATE Questions SET title = ?, contents = ?, anonymous = ?, "
					 + "edited = TRUE, dateEdited = CURRENT_TIMESTAMP WHERE id = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, title);
			pstmt.setString(2, contents);
			pstmt.setBoolean(3, anonymity);
			pstmt.setInt(4, id);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Edits an <code>Answer</code> in the database. Should only be called by <code>AnswerList</code>
	 * @param contents the new contents of the <code>Answer</code>
	 * @param anonymity the new anonymity of the <code>Answer</code>
	 * @param id the ID of the <code>Answer</code>
	 * @see QuestionAndAnswer.Answer
	 * @see QuestionAndAnswer.AnswerList#editAnswer(int, String, boolean, String)
	 */
	public void editAnswer(String contents, boolean anonymity, int id) {
		String query = "UPDATE Answers SET contents = ?, anonymous = ?, "
					 + "edited = TRUE, dateEdited = CURRENT_TIMESTAMP WHERE id = ?";
		try(PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, contents);
			pstmt.setBoolean(2, anonymity);
			pstmt.setInt(3, id);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Edits a <code>Review</code> in the database. Should only be called by <code>ReviewList</code>.
	 * @param id the ID number of the <code>Review</code> being edited
	 * @param contents the contents of the <code>Review</code>
	 * @see Review.Review
	 * @see Review.ReviewList#editReview(int, String, String)
	 */
	public void editReview(int id, String contents)
	{
		String query = "UPDATE Reviews SET contents = ?, edited = TRUE, dateEdited = CURRENT_TIMESTAMP WHERE id = ?";
		try(PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, contents);
			pstmt.setInt(2, id);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Marks an <code>Question</code> as resolved.
	 * Should only be called by <code>QuestionList</code>
	 * @param id the ID of the question.
	 * @see QuestionAndAnswer.Question
	 * @see QuestionAndAnswer.QuestionList#markResolved(int, String)
	 */
	public void resolveQuestion(int id) {
		String query = "UPDATE Questions SET resolved = TRUE WHERE id = ?";
		try(PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setInt(1, id);
			pstmt.executeUpdate();
		} catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Marks an <code>Answer</code> as resolved.
	 * Should only be called by <code>AnswerList</code>
	 * @param id the ID of the answer.
	 * @see QuestionAndAnswer.Answer
	 * @see QuestionAndAnswer.AnswerList#markResolved(int, String)
	 */
	public void resolveAnswer(int id) {
		String query = "UPDATE Answers SET resolved = TRUE WHERE id = ?";
		try(PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setInt(1, id);
			pstmt.executeUpdate();
		} catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Deletes a <code>Questions</code> from the database, including all corresponding <code>Answer</code> replies.
	 * Should only be called by <code>QuestionList</code>.
	 * @param id the ID of the <code>Question</code>
	 * @return a boolean where true indicates a successful deletion
	 * @see QuestionAndAnswer.Question
	 * @see QuestionAndAnswer.QuestionList#deleteQuestion(int, String)
	 */
	public boolean deleteQuestion(int id) {
		String query = "SELECT id FROM Answers WHERE questionID = ?";
		String query2 = "DELETE FROM Questions WHERE id = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query);
				PreparedStatement pstmt2 = connection.prepareStatement(query2)) {
			pstmt.setInt(1, id);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next())
				deleteAnswer(rs.getInt("id"));
			pstmt2.setInt(1, id);
			int result = pstmt2.executeUpdate();
			if(result >= 1) {
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	/**
	 * Deletes an <code>Answer</code> from the database, including all corresponding <code>Answer</code> replies.
	 * Should only be called by <code>AnswerList</code>.
	 * @param id the ID of the <code>Answer</code>
	 * @return a boolean where true indicates a successful deletion
	 * @see QuestionAndAnswer.Answer
	 * @see QuestionAndAnswer.AnswerList#deleteAnswer(int, String)
	 */
	public boolean deleteAnswer(int id) {
		String query = "SELECT id FROM Answers WHERE answerID = ?";
		String query2 = "SELECT id FROM Reviews WHERE answerID = ?";
		String query3 = "DELETE FROM Answers WHERE id = ?";
		try(PreparedStatement pstmt = connection.prepareStatement(query);
				PreparedStatement pstmt2 = connection.prepareStatement(query2);
				PreparedStatement pstmt3 = connection.prepareStatement(query3)) {
			pstmt.setInt(1, id);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next())
				deleteAnswer(rs.getInt("id"));
			pstmt2.setInt(1, id);
			ResultSet rs2 = pstmt2.executeQuery();
			while(rs2.next())
				deleteReview(rs2.getInt("id"));
			pstmt3.setInt(1, id);
			int result = pstmt3.executeUpdate();
			if(result >= 1)
				return false;
		} catch(SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	/**
	 * Deletes a <code>Review</code> from the database. Should only be called by <code>ReviewList</code>.
	 * @param id the ID number of the <code>Review</code> being edited
	 * @see Review.Review
	 * @see Review.ReviewList#deleteReview(int, String)
	 */
	public boolean deleteReview(int id) {
		String query = "SELECT id FROM Answers WHERE reviewID = ?";
		String query2 = "DELETE FROM Reviews WHERE id = ?";
		try(PreparedStatement pstmt = connection.prepareStatement(query);
				PreparedStatement pstmt2 = connection.prepareStatement(query2)) {
			pstmt.setInt(1, id);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next())
				deleteAnswer(rs.getInt("id"));
			pstmt2.setInt(1, id);
			int result = pstmt2.executeUpdate();
			if(result >= 1) {
				return true;
			}
		} catch(SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	/**
	 * Checks if a Question exists.
	 * @param title the title of the question
	 * @return boolean where true indicates existence
	 */
	public boolean doesQuestionExist(String title) {
		String query = "SELECT COUNT(*) FROM Questions WHERE title = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        
	        pstmt.setString(1, title);
	        ResultSet rs = pstmt.executeQuery();
	        
	        if (rs.next()) {
	            // If the count is greater than 0, the question exists
	            return rs.getInt(1) > 0;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return false; // If an error occurs, assume question doesn't exist
	}
	
	/**
	 * Gets a question by title
	 * @param t the title of the question
	 * @return a question
	 * @see QuestionAndAnswer.Question
	 */
	public Question getQuestionByTitle(String t) {
		String query = "SELECT * FROM Questions WHERE title = ?";
		
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, t);
	        ResultSet rs = pstmt.executeQuery();
	        
	        if (rs.next()) {
	        	int id = rs.getInt("id");
	            String userName = rs.getString("userName");
	            String title = rs.getString("title");
	            String contents = rs.getString("contents");
	            Timestamp datePosted = rs.getTimestamp("datePosted");
	            Timestamp dateEdited = rs.getTimestamp("dateEdited");
	            boolean edited = rs.getBoolean("edited");
	            boolean anonymous = rs.getBoolean("anonymous");
	            boolean resolved = rs.getBoolean("resolved");
	            
	            return new Question(id, title, contents, userName, anonymous, datePosted, dateEdited, edited, resolved, 0);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return null; // If no user exists or an error occurs
	}
	
	/**
	 * Returns all of the questions in the database as Question objects in an ArrayList.
	 * @return all of the questions in the database as Question objects in an ArrayList
	 * @see QuestionAndAnswer.Question
	 * @see QuestionAndAnswer.QuestionList#getAllQuestions()
	 */
	public ArrayList<Question> loadQuestions() {
		String query = "SELECT * FROM Questions";
		try(ResultSet rs = statement.executeQuery(query)) {
		
			ArrayList<Question> temp = new ArrayList<Question>();
			while (rs.next()) {
				int id = rs.getInt("id");
	            String userName = rs.getString("userName");
	            String title = rs.getString("title");
	            String contents = rs.getString("contents");
	            Timestamp datePosted = rs.getTimestamp("datePosted");
	            Timestamp dateEdited = rs.getTimestamp("dateEdited");
	            boolean edited = rs.getBoolean("edited");
	            boolean anonymous = rs.getBoolean("anonymous");
	            boolean resolved = rs.getBoolean("resolved");
	             
	            temp.add(new Question(id, title, contents, userName, anonymous, datePosted, dateEdited, edited, resolved, 0));
			}
			return temp;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * Returns a specific question from the id number.
	 * Should only be called by QuestionList.
	 * @param id the ID of the Question
	 * @return a Question object
	 * @see QuestionAndAnswer.Question
	 * @see QuestionAndAnswer.QuestionList#getQuestion(int)
	 */
	public Question getQuestionByID(int id) {
		String query = "SELECT * FROM Questions WHERE id = ?";
		try(PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setInt(1, id);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()) {
	            String userName = rs.getString("userName");
	            String title = rs.getString("title");
	            String contents = rs.getString("contents");
	            Timestamp datePosted = rs.getTimestamp("datePosted");
	            Timestamp dateEdited = rs.getTimestamp("dateEdited");
	            boolean edited = rs.getBoolean("edited");
	            boolean anonymous = rs.getBoolean("anonymous");
	            boolean resolved = rs.getBoolean("resolved");
	            
	            return new Question(id, title, contents, userName, anonymous, datePosted, dateEdited, edited, resolved, 0);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return null; // If no user exists or an error occurs
	}
	
	/**
	 * Returns a specific Answer by ID number.
	 * @param id the ID of the answer
	 * @return an Answer object
	 * @see QuestionAndAnswer.Answer
	 */
	public Answer getAnswerByID(int id) {
		String query = "SELECT * FROM Answers WHERE id = ?";
		try(PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setInt(1, id);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()) {
				int questionID = rs.getInt("questionID");
				int answerID = rs.getInt("answerID");
				int reviewID = rs.getInt("reviewID");
				String userName = rs.getString("userName");
				String contents = rs.getString("contents");
				Timestamp datePosted = rs.getTimestamp("datePosted");
				Timestamp dateEdited = rs.getTimestamp("dateEdited");
				boolean edited = rs.getBoolean("edited");
				boolean anonymous = rs.getBoolean("anonymous");
				boolean resolved = rs.getBoolean("Resolved");
				boolean isPrivate = rs.getBoolean("private");
				
				return new Answer(id, questionID, answerID, reviewID, contents, userName, anonymous, datePosted, edited, dateEdited, resolved, isPrivate);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return null; // If no user exists or an error occurs
	}
	
	/**
	 * Gets a <code>Review</code> by ID number. Should only be called by <code>ReviewList</code>.
	 * @param id the ID number of the <code>Review</code>
	 * @return a <code>Review</code> object containing the review data
	 * @see Review.Review
	 * @see Review.ReviewList#getReview(int)
	 */
	public Review getReviewByID(int id) {
		String query = "SELECT * FROM Reviews WHERE id = ?";
		try(PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setInt(1, id);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()) {
				int questionID = rs.getInt("questionID");
				int answerID = rs.getInt("answerID");
				String userName = rs.getString("userName");
				String contents = rs.getString("contents");
				Timestamp datePosted = rs.getTimestamp("datePosted");
				Timestamp dateEdited = rs.getTimestamp("dateEdited");
				boolean edited = rs.getBoolean("edited");
				
				return new Review(id, questionID, answerID, contents, userName, datePosted, edited, dateEdited);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return null; // If no user exists or an error occurs
	}
	
	
	/**
	 * Gets all questions by a specific user.
	 * Should only be called by QuestionList
	 * @param userName the userName of the specified user
	 * @return an ArrayList containing all Questions by user
	 * @see QuestionAndAnswer.Question
	 * @see QuestionAndAnswer.QuestionList#getAllQuestionsByUser(String)
	 */
	public ArrayList<Question> getQuestionsByUser(String userName) {
		String query = "SELECT * FROM Questions WHERE userName = ?";
		try(PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, userName);
			ResultSet rs = pstmt.executeQuery();
			ArrayList<Question> temp = new ArrayList<Question>();
			while (rs.next()) {
				int id = rs.getInt("id");
	            String title = rs.getString("title");
	            String contents = rs.getString("contents");
	            Timestamp datePosted = rs.getTimestamp("datePosted");
	            Timestamp dateEdited = rs.getTimestamp("dateEdited");
	            boolean edited = rs.getBoolean("edited");
	            boolean anonymous = rs.getBoolean("anonymous");
	            boolean resolved = rs.getBoolean("resolved");
	            
	            temp.add(new Question(id, title, contents, userName, anonymous, datePosted, dateEdited, edited, resolved, 0));
			}
			return temp;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * Gets all questions by a specific reviewer.
	 * Should only be called by QuestionList
	 * @param userName the userName of the specified reviewer
	 * @return an ArrayList containing all Questions by user
	 * @see QuestionAndAnswer.Question
	 * @see QuestionAndAnswer.QuestionList#getQuestionsByReviewer(String)
	 */
	public ArrayList<Question> getQuestionByReviewer(String userName){
		String query = " SELECT DISTINCT q.* "
					 + "FROM questions q "
					 + "JOIN reviews r ON q.id = r.questionID "
					 + "WHERE r.userName = ?";
		try(PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, userName);
			ResultSet rs = pstmt.executeQuery();
			ArrayList<Question> temp = new ArrayList<Question>();
			while (rs.next()) {
				int id = rs.getInt("id");
	            String title = rs.getString("title");
	            String contents = rs.getString("contents");
	            Timestamp datePosted = rs.getTimestamp("datePosted");
	            Timestamp dateEdited = rs.getTimestamp("dateEdited");
	            boolean edited = rs.getBoolean("edited");
	            boolean anonymous = rs.getBoolean("anonymous");
	            boolean resolved = rs.getBoolean("resolved");
	            
	            temp.add(new Question(id, title, contents, userName, anonymous, datePosted, dateEdited, edited, resolved, 0));
			}
			return temp;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * Gets all <code>Reviews</code> by a specific user from a specific question. Should only be called by <code>ReviewList</code>.
	 * @param userName the userName
	 * @param questionID the id of the question
	 * @return an ArrayList of <code>Reviews</code>
	 * @see Review.Review
	 * @see Review.ReviewList#getAllReviewsByUserAndQuestion(String, Int)
	 */
	public ArrayList<Review> getReviewByQuestionAndReviewer(String userName, int questionID){
		String query = "SELECT * FROM Reviews WHERE userName = ? AND questionID = ?";
		try(PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, userName);
			pstmt.setInt(2, questionID);
			ResultSet rs = pstmt.executeQuery();
			ArrayList<Review> temp = new ArrayList<Review>();
			while(rs.next()) {
				int id = rs.getInt("id");
				int answerID = rs.getInt("answerID");
				String contents = rs.getString("contents");
				Timestamp datePosted = rs.getTimestamp("datePosted");
				Timestamp dateEdited = rs.getTimestamp("dateEdited");
				boolean edited = rs.getBoolean("edited");
				
				temp.add(new Review(id, questionID, answerID, contents, userName, datePosted, edited, dateEdited));
	        }
			return temp;
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return null; // If no user exists or an error occurs
	}
	
	/**
	 * Gets all <code>Reviews</code> by a specific user. Should only be called by <code>ReviewList</code>.
	 * @param userName the userName
	 * @return an ArrayList of <code>Reviews</code>
	 * @see Review.Review
	 * @see Review.ReviewList#getAllReviewsByUser(String)
	 */
	public ArrayList<Review> getReviewsByUser(String userName) {
		String query = "SELECT * FROM Reviews WHERE userName = ?";
		try(PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, userName);
			ResultSet rs = pstmt.executeQuery();
			ArrayList<Review> temp = new ArrayList<Review>();
			while(rs.next()) {
				int id = rs.getInt("id");
				int questionID = rs.getInt("questionID");
				int answerID = rs.getInt("answerID");
				String contents = rs.getString("contents");
				Timestamp datePosted = rs.getTimestamp("datePosted");
				Timestamp dateEdited = rs.getTimestamp("dateEdited");
				boolean edited = rs.getBoolean("edited");
				
				temp.add(new Review(id, questionID, answerID, contents, userName, datePosted, edited, dateEdited));
	        }
			return temp;
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return null; // If no user exists or an error occurs
	}
	
	/**
	 * Gets all Answers to a specific Question.
	 * Should only be called by AnswerList
	 * @param questionID the ID of the Question
	 * @return an ArrayList containing all Answers to the question.
	 * @see QuestionAndAnswer.Question
	 * @see QuestionAndAnswer.Answer
	 * @see QuestionAndAnswer.AnswerList#getAnswersByQuestion(int)
	 */
	public ArrayList<Answer> getAnswerByQuestion(int questionID) {
		String query = "SELECT * FROM Answers WHERE questionID = ?";
		try(PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setInt(1, questionID);
			ResultSet rs = pstmt.executeQuery();
			ArrayList<Answer> temp = new ArrayList<Answer>();
			while(rs.next()) {
				int id = rs.getInt("id");
				int answerID = rs.getInt("answerID");
				int reviewID = rs.getInt("reviewID");
				String userName = rs.getString("userName");
				String contents = rs.getString("contents");
				Timestamp datePosted = rs.getTimestamp("datePosted");
				Timestamp dateEdited = rs.getTimestamp("dateEdited");
				boolean edited = rs.getBoolean("edited");
				boolean anonymous = rs.getBoolean("anonymous");
				boolean resolved = rs.getBoolean("Resolved");
				boolean isPrivate = rs.getBoolean("private");
				temp.add(new Answer(id, questionID, answerID, reviewID, contents, userName, anonymous, datePosted, edited, dateEdited, resolved, isPrivate));
			}
			return temp;
		} catch(SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * Gets all Answers to a specific Review.
	 * Should only be called by AnswerList
	 * @param reviewID the ID of the Review
	 * @return an ArrayList containing all Answers to the review.
	 * @see QuestionAndAnswer.Question
	 * @see QuestionAndAnswer.Answer
	 * @see QuestionAndAnswer.AnswerList#getAnswersByReview(int)
	 */
	public ArrayList<Answer> getAnswerByReview(int reviewID) {
		String query = "SELECT * FROM Answers WHERE reviewID = ?";
		try(PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setInt(1, reviewID);
			ResultSet rs = pstmt.executeQuery();
			ArrayList<Answer> temp = new ArrayList<Answer>();
			while(rs.next()) {
				int id = rs.getInt("id");
				int answerID = rs.getInt("answerID");
				int questionID = rs.getInt("questionID");
				String userName = rs.getString("userName");
				String contents = rs.getString("contents");
				Timestamp datePosted = rs.getTimestamp("datePosted");
				Timestamp dateEdited = rs.getTimestamp("dateEdited");
				boolean edited = rs.getBoolean("edited");
				boolean anonymous = rs.getBoolean("anonymous");
				boolean resolved = rs.getBoolean("Resolved");
				boolean isPrivate = rs.getBoolean("private");
				temp.add(new Answer(id, questionID, answerID, reviewID, contents, userName, anonymous, datePosted, edited, dateEdited, resolved, isPrivate));
			}
			return temp;
		} catch(SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * Gets all <code>Reviews</code> by for a specific question.
	 * @param questionID the ID of the question
	 * @return an ArrayList of <code>Reviews</code>
	 * @see Review.Review
	 * @see Review.ReviewList#getAllReviewsByUser(String)
	 */
	public ArrayList<Review> getReviewsByQuestion(int questionID) {
		String query = "SELECT * FROM Reviews WHERE questionID = ?";
		try(PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setInt(1, questionID);
			ResultSet rs = pstmt.executeQuery();
			ArrayList<Review> temp = new ArrayList<Review>();
			while(rs.next()) {
				int id = rs.getInt("id");
				int answerID = rs.getInt("answerID");
				String contents = rs.getString("contents");
				String userName = rs.getString("userName");
				Timestamp datePosted = rs.getTimestamp("datePosted");
				Timestamp dateEdited = rs.getTimestamp("dateEdited");
				boolean edited = rs.getBoolean("edited");
				
				temp.add(new Review(id, questionID, answerID, contents, userName, datePosted, edited, dateEdited));
	        }
			return temp;
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return null; // If no user exists or an error occurs
	}
	
	/**
	 * Marks a reviewer as trusted to the database.
	 * @param studentUserName the username of the truster
	 * @param reviewerUserName the username of the trustee
	 * @param weight the weight given to the reviewer
	 * @return true if added, false if already exists
	 */
	public boolean addTrustedReviewer(String studentUserName, String reviewerUserName, int weight) {
		String query = "SELECT * FROM TrustedReviewers WHERE studentName = ? AND reviewerName = ?";
		String query2 = "INSERT INTO TrustedReviewers(studentName, reviewerName, reviewerWeight) VALUES (?, ?, ?)";
		try(PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, studentUserName);
			pstmt.setString(2, reviewerUserName);
			ResultSet rs = pstmt.executeQuery();
			// if the reviewer is already trusted, return false
			if(rs.next())
				return false;
			PreparedStatement pstmt2 = connection.prepareStatement(query2);
			pstmt2.setString(1, studentUserName);
			pstmt2.setString(2, reviewerUserName);
			pstmt2.setInt(3, weight);
			pstmt2.executeUpdate();
			return true;
		} catch (SQLException e) {
	        e.printStackTrace();
	    }
		return false;
	}
	
	/**
	 * Edits a reviewers weight.
	 * @param studentUserName the username of the student
	 * @param reviewerUserName the username of the reviewer
	 * @param weight the weight given to the reviewer
	 * @return true if edited, false if doesn't exist
	 */
	public boolean editTrustedReviewerWeight(String studentUserName, String reviewerUserName, int weight) {
		String query = "SELECT * FROM TrustedReviewers WHERE studentName = ? AND reviewerName = ?";
		String query2 = "UPDATE TrustedReviewers SET reviewerWeight = ? WHERE studentName = ? AND reviewerName = ?";
		try(PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, studentUserName);
			pstmt.setString(2, reviewerUserName);
			ResultSet rs = pstmt.executeQuery();
			// if the reviewer is not trusted, can't update
			if(!rs.next())
				return false;
			PreparedStatement pstmt2 = connection.prepareStatement(query2);
			pstmt2.setInt(1, weight);
			pstmt2.setString(2, studentUserName);
			pstmt2.setString(3, reviewerUserName);
			pstmt2.executeUpdate();
			return true;
		} catch (SQLException e) {
	        e.printStackTrace();
	    }
		return false;
	}
	
	/**
	 * Deletes a trusted reviewer from the database.
	 * @param studentUserName the username of the student
	 * @param reviewerUserName the username of the reviewer
	 * @return true if deleted
	 */
	public boolean deleteTrustedReviewer(String studentUserName, String reviewerUserName) {
		String query = "DELETE FROM TrustedReviewers WHERE studentName = ? AND reviewerName = ?";
		try(PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, studentUserName);
			pstmt.setString(2, reviewerUserName);
			int result = pstmt.executeUpdate();
			if(result >= 1)
				return true;
		} catch (SQLException e) {
	        e.printStackTrace();
	    }
		return false;
	}
	
	/**
	 * Gets the usernames of all reviewers a student trusts and returns them, sorted by weight.
	 * The higher weighted reviewers are at a lower index in the list.
	 * @param studentUserName the username of the student
	 * @return an ArrayList of the reviewers usernames
	 */
	public ArrayList<String> getTrustedReviewers(String studentUserName) {
		String query = "SELECT * FROM TrustedReviewers WHERE studentName = ?";
		try(PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, studentUserName);
			ResultSet rs = pstmt.executeQuery();
			ArrayList<String> temp = new ArrayList<String>();
			ArrayList<Integer> tempWeight = new ArrayList<Integer>();
			while(rs.next()) {
				temp.add(rs.getString("reviewerName"));
				tempWeight.add(rs.getInt("reviewerWeight"));
			}
			
			// use insertion sort to sort the reviewers by weight, could use fast algorithm
			for(int i = 1; i < temp.size(); i++)
			{
				int key = tempWeight.get(i);
				String key_value = temp.get(i);
				int j = i-1;
				while(j >= 0 && tempWeight.get(j) < key)
				{
					tempWeight.set(j+1, tempWeight.get(j));
					temp.set(j+1, temp.get(j));
					j = j-1;
				}
				tempWeight.set(j+1, key);
				temp.set(j+1, key_value);
			}
			return temp;
		} catch (SQLException e) {
	        e.printStackTrace();
	    }
		return null;
	}
	
	/**
	 * Gets the weights of all reviewers a student trusts and returns them, sorted by weight.
	 * The higher weighted reviewers are at a lower index in the list.
	 * @param studentUserName the username of the student
	 * @return an ArrayList of the reviewers weights
	 */
	public ArrayList<Integer> getTrustedReviewersWeight(String studentUserName) {
		String query = "SELECT * FROM TrustedReviewers WHERE studentName = ?";
		try(PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, studentUserName);
			ResultSet rs = pstmt.executeQuery();
			ArrayList<Integer> tempWeight = new ArrayList<Integer>();
			while(rs.next()) {
				tempWeight.add(rs.getInt("reviewerWeight"));
			}
			
			// use insertion sort to sort the reviewers by weight, could use fast algorithm
			for(int i = 1; i < tempWeight.size(); i++)
			{
				int key = tempWeight.get(i);
				int j = i-1;
				while(j >= 0 && tempWeight.get(j) < key)
				{
					tempWeight.set(j+1, tempWeight.get(j));
					j = j-1;
				}
				tempWeight.set(j+1, key);
			}
			return tempWeight;
		} catch (SQLException e) {
	        e.printStackTrace();
	    }
		return null;
	}
	
	/**
	 * Gets the usernames and weight of all reviewers a student trusts and returns them in a string, sorted by weight.
	 * The higher weighted reviewers are at a lower index in the list.
	 * @param studentUserName the username of the student
	 * @return an String of the reviewers usernames and weight
	 */
	public String listTrustedReviewers(String studentUserName) {
		String query = "SELECT reviewerName, reviewerWeight "
				+ "FROM TrustedReviewers "
				+ "WHERE studentName= ? "
				+ "ORDER BY reviewerWeight DESC";
		try(PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, studentUserName);
			ResultSet rs = pstmt.executeQuery();
			String temp = "";
			while(rs.next()) {
				temp = temp + rs.getString("reviewerName") + " " + rs.getInt("reviewerWeight") + "\n";
			}
			return temp;
		} catch (SQLException e) {
	        e.printStackTrace();
	    }
		return null;
	}
	
	/**
	 * Inserts a request from a Student to become a reviewer into the ReviewerRequests table
	 * @param username the username of the requester
	 * @return true if request was added, false if the user already has an active request
	 */
	public boolean submitReviewerRequest(String username) {
		
		String preQuery = "SELECT * FROM ReviewerRequests WHERE username = ?";
		String query = "INSERT INTO ReviewerRequests (username) VALUES (?)";
		try(PreparedStatement prepstmt = connection.prepareStatement(preQuery)) {
			prepstmt.setString(1, username);
			ResultSet rs = prepstmt.executeQuery();
			// if the reviewer is already trusted, return false
			if(rs.next()) {
				//System.out.println("Already in the system");
				return false;
			} else {
				PreparedStatement pstmt = connection.prepareStatement(query);
				pstmt.setString(1, username);
				pstmt.executeUpdate();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return true;
	}
	
	/**
	 * Fetches the list of users who have requested to become a reviewer
	 * @return requests The usernames of Students who have requested to become Reviewers
	 */
	public ArrayList<String> getReviewerRequests() {
		ArrayList<String> requests = new ArrayList<String>();
		String query = "SELECT * FROM ReviewerRequests";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				requests.add(rs.getString("username"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return requests;
	}
	
	/**
	 * Removes a user's request to become a reviewer. This occurs once a decision (whether confirmation or denial) has been made on their request.
	 * @param username The user whose request will be removed from the table.
	 */
	public void deleteRequest(String username) {
		String query = "DELETE FROM ReviewerRequests WHERE username = ?";
		try(PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, username);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	/**
	 * Fetches all Answers created by one user, specified as a parameter to this method.
	 * @param username The username whose answers will be returned.
	 * @return result The list of Answers belonging to the input user
	 */
	public ArrayList<Answer> getAnswersbyUser (String username) {
		ArrayList<Answer> result= new ArrayList<Answer>();
		String query = "SELECT * FROM answers WHERE userName = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, username);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				Answer a = new Answer(rs.getInt("id"), rs.getInt("questionID"), rs.getInt("answerID"), rs.getInt("reviewID"), rs.getString("contents"), rs.getString("username"), rs.getBoolean("anonymous"), rs.getTimestamp("datePosted"), rs.getBoolean("edited"), rs.getTimestamp("dateEdited"), rs.getBoolean("resolved"), rs.getBoolean("private") );
				result.add(a);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return result;
	}


	public void updateFeedback(int reviewID, String feedback) {
	    String sql = "UPDATE Reviews SET feedback = ? WHERE id = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
	        pstmt.setString(1, feedback);
	        pstmt.setInt(2, reviewID);
	        pstmt.executeUpdate();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}

	
	public void markQuestionAsIssue(int questionID) {
	    String update = "UPDATE Questions SET isIssue = TRUE WHERE QuestionID = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(update)) {
	        pstmt.setInt(1, questionID);
	        pstmt.executeUpdate();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}


	
	
	
	/**
	 * Closes the database connection and statement.
	 */
	public void closeConnection() {
		try{ 
			if(statement!=null) statement.close(); 
		} catch(SQLException se2) { 
			se2.printStackTrace();
		} 
		try { 
			if(connection!=null) connection.close(); 
		} catch(SQLException se){ 
			se.printStackTrace(); 
		} 
	}

}
