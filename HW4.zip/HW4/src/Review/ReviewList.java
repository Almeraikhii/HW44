package Review;

import java.util.ArrayList;

import databasePart1.*;

/**
 * Allows for the posting, editing, deleting, and getting of <code>Reviews</code>.
 * <p>
 * There is input validation for each method to ensure that only certain users may do certain operations.
 * @author Stavros Suppappola
 * @version 1.0.0, 3/29/2025
 */
public class ReviewList {
	
	private static DatabaseHelper databaseHelper;
	private ArrayList<Review> reviewList;
	public String reviewErrorMessage = "";
	
	/**
	 * Connects to the database.
	 * 
	 * @see databasePart1.DatabaseHelper
	 */
	public ReviewList(DatabaseHelper databaseHelper) {
		this.databaseHelper = databaseHelper;
		this.reviewList = new ArrayList<Review>();
	}
	
	/**
	 * Gets a specific <code>Review</code> by ID number.
	 * 
	 * @param id the ID to be searched for
	 * @return a <code>Review</code> object specified
	 * @see Review
	 * @see databasePart1.DatabaseHelper
	 */
	public Review getReview(int id) {
		return databaseHelper.getReviewByID(id);
	}
	
	/**
	 * Gets all <code>Reviews</code> from a specific reviewer.
	 * 
	 * @param userName the userName to be searched for
	 * @return an ArrayList of all <code>Reviews</code> by the reviewer
	 * @see Review
	 * @see databasePart1.DatabaseHelper
	 */
	public ArrayList<Review> getAllReviewsByUser(String userName) {
		reviewList = databaseHelper.getReviewsByUser(userName);
		return reviewList;
	}
	
	/**
	 * Gets all <code>Reviews</code> from a specific reviewer from a specific question.
	 * 
	 * @param userName the userName to be searched for
	 * @param questionID the id of the question
	 * @return an ArrayList of all <code>Reviews</code> by the reviewer
	 * @see Review
	 * @see databasePart1.DatabaseHelper
	 */
	public ArrayList<Review> getAllReviewsByUserAndQuestion(String userName, int questionID){
		reviewList = databaseHelper.getReviewByQuestionAndReviewer(userName, questionID);
		return reviewList;
	}
	
	/**
	 * Gets all <code>Reviews</code> from a specific question.
	 * 
	 * @param questionID the ID of the question
	 * @return an ArrayList of all <code>Reviews</code>
	 * @see Review
	 * @see databasePart1.DatabaseHelper
	 */
	public ArrayList<Review> getAllReviewsByQuestion(int questionID) {
		reviewList = databaseHelper.getReviewsByQuestion(questionID);
		return reviewList;
	}
	
	/**
	 * Checks a <code>Review</code> and if valid, adds it to the database.
	 * 
	 * The contents must be at least 10 and at most 5000 characters. The poster must be a reviewer.
	 * 
	 * @param questionID the ID number of the <code>Question</code> the Answer is answering
	 * @param answerID the ID number of the <code>Answer</code> being replied to
	 * @param contents the contents of the <code>Review</code>
	 * @param userName the userName of the poster
	 * @return a boolean where true indicates the <code>Review</code> was successfully posted
	 * @see Review
	 * @see databasePart1.DatabaseHelper
	 */
	public boolean addReview(int questionID, int answerID, String contents, String userName) {
		// reviewer role is XXXX1
		if(databaseHelper.getUserRole(userName).charAt(4) != '1')
		{
			reviewErrorMessage = "You must be a reviewer to post a review.\n";
			return false;
		}
		else if(contents.length() < 10) {
			reviewErrorMessage = "Contents must be at least 10 characters.\n";
			return false;
		}
		else if(contents.length() > 5000) {
			reviewErrorMessage = "Contents must be no more than 5000 characters.\n";
			return false;
		}
		reviewErrorMessage = "";
		databaseHelper.postReview(questionID, answerID, userName, contents);
		return true;
	}
	
	/**
	 * Checks a <code>Review</code> and if valid, edits the <code>Review</code>.
	 * 
	 * The contents must be at least 10 and at most 5000 characters.
	 * The userName of the editor must be the same as the poster.
	 * 
	 * @param id the ID of the <code>Review</code> to be edited
	 * @param contents the new contents
	 * @param userName the userName of the editor
	 * @return a boolean where true indicates the <code>Review</code> was successfully edited
	 * @see Review
	 * @see databasePart1.DatabaseHelper
	 */
	public boolean editReview(int id, String contents, String userName) {
		if(contents.length() < 10) {
			reviewErrorMessage = "Contents must be at least 10 characters.\n";
			return false;
		}
		else if(contents.length() > 5000) {
			reviewErrorMessage = "Contents must be no more than 5000 characters.\n";
			return false;
		}
		Review toBeEdited = databaseHelper.getReviewByID(id);
		// if username does not match creator
		if(!toBeEdited.getUserName().equals(userName))
		{
			reviewErrorMessage = "You are not authorized to edit this review.\n";
			return false;
		}
		reviewErrorMessage = "";
		databaseHelper.editReview(id, contents);;
		return true;
	}
	
	/**
	 * Deletes a <code>Review</code> from the database, only if the deleter was the one who posted.
	 * 
	 * @param id the ID of the <code>Review</code> to be deleted
	 * @param userName the userName of the poster
	 * @return a boolean where true indicates the <code>Review</code> was successfully deleted
	 * @see Review
	 * @see databasePart1.DatabaseHelper
	 */
	public boolean deleteReview(int id, String userName) {
		Review toBeEdited = databaseHelper.getReviewByID(id);
		// if username does not match creator, or the deletor is not an admin (admin is 1XXXX)
		if(!toBeEdited.getUserName().equals(userName) && databaseHelper.getUserRole(userName).charAt(0) != '1')
		{
			reviewErrorMessage = "You are not authorized to delete this review.\n";
			return false;
		}
		reviewErrorMessage = "";
		databaseHelper.deleteReview(id);
		return true;
	}
	
}
