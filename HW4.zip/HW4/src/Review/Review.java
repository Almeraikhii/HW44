package Review;

import java.time.Instant;
import java.sql.Timestamp;
import java.time.Duration;

/**
 * The Review class represents a single answer, and contains necessary information such as the answer contents, the author, etc.
 * 
 * @author Stavros Suppappola
 * @version 1.0.0, 3/29/2025
 */
public class Review {
	
	// Relevant data of a review
	private int id;
	private int answerID;
	private int questionID;
	private String contents;
	private String userName;
	private Instant datePosted;
	private boolean edited;
	private Instant dateEdited;
	
	/**
	 * Creates an instance of a <code>Review</code>. Should only be called by the databaseHelper class
	 * @param id the ID number of the <code>Review</code>
	 * @param questionID the ID number of the <code>Question</code> of the Answer is answering
	 * @param answerID the ID number of the <code>Answer</code> which is being reviewed
	 * @param contents the contents of the <code>Review</code>
	 * @param userName the userName of the reviewer
	 * @param datePosted the date the reviewer posted the <code>Review</code>
	 * @param edited whether the <code>Review</code> was edited
	 * @param dateEdited the date the <code>Review</code> was edited
	 */
	public Review (int id, int questionID, int answerID, String contents, String userName, Timestamp datePosted, boolean edited, Timestamp dateEdited) {
		this.id = id;
		this.questionID = questionID;
		this.answerID = answerID;
		this.contents = contents;
		this.userName = userName;
		this.edited = edited;
		this.datePosted = datePosted.toInstant();
		if (dateEdited != null) {	
			this.dateEdited = dateEdited.toInstant();
		}
		else {
			this.dateEdited = null;
		}

	}

private String feedback; 

    public void setFeedback(String feedback) {
        this.feedback = feedback;
    }

    public String getFeedback() {
        return this.feedback;
    }

	
	
	/**
	 * Returns the ID number of a <code>Review</code>.
	 * @return ID number
	 */
	public int getID() { return id; }
	
	/**
	 * Returns the contents of a <code>Review</code>.
	 * @return the contents
	 */
	public String getContents() { return contents; }
				
	/**
	 * Returns the userName of the reviewer.
	 * @return the userName of the reviewer
	 */
	public String getUserName() { return userName; }
			
	/**
	 * Returns the ID number of the <code>Question</code> the answer is answering.
	 * @return the ID number of the <code>Question</code> the answer is answering
	 */
	public int getQuestionID() { return questionID; }
	
	/**
	 * Returns the ID number of the <code>Answer</code> being reviewed.
	 * @return the ID number of the <code>Answer</code> being reviewed
	 */
	public int getAnswerID() { return answerID; }
	
	/**
	 * Determines how long ago a <code>Review</code> was posted/edited.
	 * @return a string containing info about the post date
	 */
	public String getDatePosted() {
		Instant currentTime = Instant.now();
		String dateMessage = "";
		dateMessage += getTimeAgo(datePosted, currentTime);
		if(edited)
			dateMessage += " (Edited " + getTimeAgo(dateEdited, currentTime) + ")";
		return dateMessage;
	}
	
	/**
	 * Helper method to see describe how long ago.
	 * 
	 * @param originalTime the timestamp of when this <code>Review</code> was posted
	 * @param currentTime the current time
	 * @return a String describing how long ago
	 * @see #getDatePosted()
	 */
	private String getTimeAgo(Instant originalTime, Instant currentTime) {
		double time = Duration.between(originalTime, currentTime).getSeconds();
		int seconds = (int)(time + 0.5);
		if(seconds < 60)
			return seconds + " second" + ((seconds == 1) ? "" : "s") + " ago";
		int minutes = (int)(time / 60 + 0.5);
		if(minutes < 60)
			return minutes + " minute" + ((minutes == 1) ? "" : "s") + " ago";
		int hours = (int)(time / 3600 + 0.5);
		if(hours < 24)
			return hours + " hour" + ((hours == 1) ? "" : "s") + " ago";
		int days = (int)(time / 86400 + 0.5);
		if(days < 7)
			return days + " day" + ((days == 1) ? "" : "s") + " ago";
		int weeks = (int)(time / 604800 + 0.5);
		if(days < 52)
			return weeks + " week" + ((weeks == 1) ? "" : "s") + " ago";
		int years = (int)(time / 31536000 + 0.5);
		return years + " year" + ((years == 1) ? "" : "s") + " ago";
	}
}
