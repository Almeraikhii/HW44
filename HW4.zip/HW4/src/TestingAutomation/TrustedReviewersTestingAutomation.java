package TestingAutomation;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import QuestionAndAnswer.AnswerList;
import QuestionAndAnswer.QuestionList;
import Review.ReviewList;
import application.User;
import databasePart1.DatabaseHelper;

/**
 * Tests adding trusted reviewers to the database, and retrieving them.
 * NOTE: In order for the testing to work, you must uncomment line 46 (statement.execute("DROP ALL OBJECTS");) in DatabaseHelper.
 * @author Stavros Suppappola
 * @version 1.0.0
 * @see databasePart1.DatabaseHelper
 */
public class TrustedReviewersTestingAutomation {
	
	private static DatabaseHelper databaseHelper;
	private static User reviewer = new User("reviewer", "P4ssword!", "00001", "reviewer@gmail.com");
	private static User reviewer2 = new User("reviewer2", "P4ssword!", "00001", "reviewer2@gmail.com");
	private static User reviewer3 = new User("reviewer3", "P4ssword!", "00001", "reviewer2@gmail.com");
	private static User student = new User("student", "P4ssword!", "01000", "student@gmail.com");
	private static User student2 = new User("student2", "P4ssword!", "01000", "student2@gmail.com");

	/**
	 * Sets up the database.
	 */
	@BeforeClass
	public static void setUpDatabase() {
		// make database object
		databaseHelper = new DatabaseHelper();
	}
	
	/**
	 *  This method resets the database with only two reviews and some users.
	 *  @see databasePart1.databaseHelper
	 */
	@Before
	public void resetDatabase() {
		try {
			// reset database
			databaseHelper.connectToDatabase();
			// register users
			databaseHelper.register(reviewer);
			databaseHelper.register(reviewer2);
			databaseHelper.register(reviewer3);
			databaseHelper.register(student);
			databaseHelper.register(student2);
			// add trusted reviewers
			databaseHelper.addTrustedReviewer(student.getUserName(), reviewer.getUserName(), 1);
			databaseHelper.addTrustedReviewer(student.getUserName(), reviewer2.getUserName(), 10);
			databaseHelper.addTrustedReviewer(student2.getUserName(), reviewer.getUserName(), 2);
			databaseHelper.addTrustedReviewer(student2.getUserName(), reviewer2.getUserName(), 7);
			databaseHelper.addTrustedReviewer(student2.getUserName(), reviewer3.getUserName(), 5);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	

	/**
	 * This test ensures that people can add trusted reviewers.
	 * @see databasePart1.DatabaseHelper#addTrustedReviewer(String, String, int)
	 */
	@Test
	public void addTrustedReviewer() {
		// adding trusted reviewer
		assertTrue(databaseHelper.addTrustedReviewer(student.getUserName(), reviewer3.getUserName(), 5));
		// check that the number increased
		assertEquals(3, databaseHelper.getTrustedReviewers(student.getUserName()).size());
	}
	
	/**
	 * This test ensures that people can't add trusted reviewers if they're already trusted.
	 * @see databasePart1.DatabaseHelper#addTrustedReviewer(String, String, int)
	 */
	@Test
	public void addExistingTrustedReviewer() {
		// adding trusted reviewer
		assertFalse(databaseHelper.addTrustedReviewer(student.getUserName(), reviewer.getUserName(), 5));
		// check that the number didnt change
		assertEquals(2, databaseHelper.getTrustedReviewers(student.getUserName()).size());
	}
	
	/**
	 * This test ensures that people can add multiple trusted reviewers.
	 * @see databasePart1.DatabaseHelper#addTrustedReviewer(String, String, int)
	 */
	@Test
	public void addMultipleTrustedReviewers() {
		// done by the Before class, check that there are multiple reviewers in each student's list
		assertEquals(2, databaseHelper.getTrustedReviewers(student.getUserName()).size());
		assertEquals(3, databaseHelper.getTrustedReviewers(student2.getUserName()).size());
	}
	
	/**
	 * This test ensures that students can edit trusted reviewers weights.
	 * @see databasePart1.DatabaseHelper#editTrustedReviewerWeight(String, String, int)
	 */
	@Test
	public void editTrustedReviewerWeight() {
		// edit trusted reviewer
		assertTrue(databaseHelper.editTrustedReviewerWeight(student.getUserName(), reviewer.getUserName(), 5));
		// check that the number didnt change
		assertEquals(2, databaseHelper.getTrustedReviewers(student.getUserName()).size());
	}
	
	/**
	 * This test ensures that students can't edit trusted reviewers weights if they are not trusted.
	 * @see databasePart1.DatabaseHelper#editTrustedReviewerWeight(String, String, int)
	 */
	@Test
	public void editNonexistentTrustedReviewer() {
		// edit trusted reviewer
		assertFalse(databaseHelper.editTrustedReviewerWeight(student.getUserName(), reviewer3.getUserName(), 5));
		// check that the number didnt change
		assertEquals(2, databaseHelper.getTrustedReviewers(student.getUserName()).size());
	}
	
	/**
	 * This test ensures that students can delete trusted reviewers.
	 * @see databasePart1.DatabaseHelper#deleteTrustedReviewer(String, String)
	 */
	@Test
	public void deleteTrustedReviewer() {
		// delete trusted reviewer
		assertTrue(databaseHelper.deleteTrustedReviewer(student.getUserName(), reviewer.getUserName()));
		// check that the number changed
		assertEquals(1, databaseHelper.getTrustedReviewers(student.getUserName()).size());
	}
	
	/**
	 * This test ensures that students can't delete trusted reviewers if they aren't trusted.
	 * @see databasePart1.DatabaseHelper#deleteTrustedReviewer(String, String)
	 */
	@Test
	public void deleteNonexistentTrustedReviewer() {
		// delete nonexitent trusted reviewer
		assertFalse(databaseHelper.deleteTrustedReviewer(student.getUserName(), reviewer3.getUserName()));
		// check that the number didnt change
		assertEquals(2, databaseHelper.getTrustedReviewers(student.getUserName()).size());
	}
	
	/**
	 * This test ensures that students can't delete other student's trusted reviewers.
	 * @see databasePart1.DatabaseHelper#deleteTrustedReviewer(String, String)
	 */
	@Test
	public void deleteOtherTrustedReviewer() {
		// delete trusted reviewer
		assertTrue(databaseHelper.deleteTrustedReviewer(student.getUserName(), reviewer2.getUserName()));
		// check that the number didnt change for the other student
		assertEquals(3, databaseHelper.getTrustedReviewers(student2.getUserName()).size());
	}
	
	/**
	 * This test ensures that students can't edit other student's trusted reviewers.
	 * @see databasePart1.DatabaseHelper#editTrustedReviewerWeight(String, String, int)
	 */
	@Test
	public void editOtherTrustedReviewer() {
		// edit trusted reviewer
		assertTrue(databaseHelper.editTrustedReviewerWeight(student.getUserName(), reviewer2.getUserName(), 4));
		// check that the number didnt change for the other student
		assertEquals(3, databaseHelper.getTrustedReviewers(student2.getUserName()).size());
	}
	
	/**
	 * This test ensures that trusted reviewers are sorted by weight.
	 */
	@Test
	public void correctWeight() {
		ArrayList<String> trustedReviewers = databaseHelper.getTrustedReviewers(student2.getUserName());
		assertEquals("reviewer2", trustedReviewers.get(0));
		assertEquals("reviewer3", trustedReviewers.get(1));
		assertEquals("reviewer", trustedReviewers.get(2));
	}
	
	/**
	 * This method closes the database.
	 */
	@After
	public void disconnectFromDatabase() {
		databaseHelper.closeConnection();
	}

}
