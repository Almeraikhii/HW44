package TestingAutomation;

import QuestionAndAnswer.QuestionList;
import databasePart1.DatabaseHelper;
import QuestionAndAnswer.Question;
import QuestionAndAnswer.Answer;
import java.util.ArrayList;
import java.util.List;

public class StaffViewTest {
		
	
	public static void main(String[] args) {
	    try {
	        DatabaseHelper db = new DatabaseHelper();
	        db.connectToDatabase();  

	        QuestionList questionList = new QuestionList(db);
	        ArrayList<Question> questions = questionList.getAllQuestions();

	        System.out.println("Staff Viewing All Questions:");
	        for (Question q : questions) {
	            System.out.println("Question: " + q.getContents());
	        }

	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}
}

	
	
