package TestingAutomation;

import static org.junit.Assert.*;

import java.sql.SQLException;

import org.junit.*;

import QuestionAndAnswer.AnswerList;
import QuestionAndAnswer.QuestionList;
import Review.ReviewList;
import application.User;
import databasePart1.DatabaseHelper;

/**
 * Tests Review posting, editing, and deletion.
 * NOTE: In order for the testing to work, you must uncomment line 46 (statement.execute("DROP ALL OBJECTS");) in DatabaseHelper.
 * @author Stavros Suppappola
 * @version 1.0.0, 4/2/2025
 * @see databasePart1.DatabaseHelper
 */
public class ReviewListTestingAutomation {
	
	private static DatabaseHelper databaseHelper;
	private static QuestionList questionList;
	private static ReviewList reviewList;
	private static AnswerList answerList;
	private static User admin = new User("admin", "P4ssword!", "10000", "admin@gmail.com");;
	private static User reviewer = new User("reviewer", "P4ssword!", "00001", "reviewer@gmail.com");
	private static User reviewer2 = new User("reviewer2", "P4ssword!", "00001", "reviewer2@gmail.com");
	private static User nonReviewer = new User("nonreviewer", "P4ssword!", "01000", "student@gmail.com");
	private final String validContents = "This is a good question. I would like to add on that the...\n";

	/**
	 * This method sets up the database and lists.
	 * @see databasePart1.DatabaseHelper
	 * @see Review.ReviewList
	 * @see QuestionAndAnswer.QuestionList
	 * @see QuestionAndAnswer.AnswerList
	 */
	@BeforeClass
	public static void setUpDatabase()
	{
		// make database object
		databaseHelper = new DatabaseHelper();
		// make list objects
		questionList = new QuestionList(databaseHelper);
		reviewList = new ReviewList(databaseHelper);
		answerList = new AnswerList(databaseHelper);
	}
	
	/**
	 * This method resets the database with only two reviews and some users.
	 * @see databasePart1.DatabaseHelper
	 * @see application.User
	 * @see Review.ReviewList
	 */
	@Before
	public void resetDatabase() {
		try {
			// reset database
			databaseHelper.connectToDatabase();
			// register users
			databaseHelper.register(admin);
			databaseHelper.register(reviewer);
			databaseHelper.register(reviewer2);
			databaseHelper.register(nonReviewer);
			// add example reviews
			questionList.addQuestion("Can I have some help?", "I need some help with this question.", nonReviewer.getUserName(), false);
			AnswerList.addAnswer(1, -1, -1, "I can help you with this question!", nonReviewer.getUserName(), false, false);
			reviewList.addReview(1, 1, "This is a good answer. However, it could be improved by...\n", reviewer.getUserName());
			reviewList.addReview(1, 1, "You should not listen to this answer. It is misleading and will make your work wrong.\n", reviewer2.getUserName());
			AnswerList.addAnswer(1, -1, 1, "Hey! This review might not be very accurate.", nonReviewer.getUserName(), false, true);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * This test ensures that only reviewers can post reviews.
	 * @see Review.Review
	 * @see Review.ReviewList#addReview(int, int, String, String)
	 */
	@Test
	public void nonReviewerPosting() {
		// attempt to post a review as a nonreviewer
		assertFalse(reviewList.addReview(1, 1, "This is my review. Blah blah blah", nonReviewer.getUserName()));
		// check that error message is correct
		assertEquals("You must be a reviewer to post a review.\n", reviewList.reviewErrorMessage);
		// check that there are no new reviews posted
		assertEquals(2, reviewList.getAllReviewsByQuestion(1).size());
	}
	
	/**
	 * This test ensures that reviewers can post reviews.
	 * @see Review.Review
	 * @see Review.ReviewList#addReview(int, int, String, String)
	 */
	@Test
	public void reviewerPosting() {
		// attempt to post a review as a reviewer
		assertTrue(reviewList.addReview(1, 1, validContents, reviewer.getUserName()));
		// check that there is no error
		assertEquals("", reviewList.reviewErrorMessage);
		// check that the review was posted
		assertEquals(3, reviewList.getAllReviewsByQuestion(1).size());
		assertEquals(validContents, reviewList.getReview(3).getContents());
	}
	
	/**
	 * This test ensures that reviews can't have less than 10 characters.
	 * @see Review.Review
	 * @see Review.ReviewList#addReview(int, int, String, String)
	 */
	@Test
	public void tooShortReview() {
		String tooShort = "this is a";
		assertEquals(9, tooShort.length());
		// attempt to post a review with too short of contents
		assertFalse(reviewList.addReview(1, 1, tooShort, reviewer.getUserName()));
		// check that there is the correct error
		assertEquals("Contents must be at least 10 characters.\n", reviewList.reviewErrorMessage);
		// check that the review was not posted
		assertEquals(2, reviewList.getAllReviewsByQuestion(1).size());
	}
	
	/**
	 * This test ensures that reviews can't have more than 5000 characters.
	 * @see Review.Review
	 * @see Review.ReviewList#addReview(int, int, String, String)
	 */
	@Test
	public void tooLongReview() {
		String tooLong = "";
		for(int i = 0; i < 5001; i++)
			tooLong += "A";
		assertEquals(5001, tooLong.length());
		// attempt to post a review with too long of contents
		assertFalse(reviewList.addReview(1, 1, tooLong, reviewer.getUserName()));
		// check that there is the correct error
		assertEquals("Contents must be no more than 5000 characters.\n", reviewList.reviewErrorMessage);
		// check that the review was not posted
		assertEquals(2, reviewList.getAllReviewsByQuestion(1).size());
	}
	
	/**
	 * This test ensures that reviews can have 5000, but not over 5000 characters.
	 * @see Review.Review
	 * @see Review.ReviewList#addReview(int, int, String, String)
	 */
	@Test
	public void goodLongReview() {
		String notTooLong = "";
		for(int i = 0; i < 5000; i++)
			notTooLong += "A";
		assertEquals(5000, notTooLong.length());
		// attempt to post a review with 5000 characters
		assertTrue(reviewList.addReview(1, 1, notTooLong, reviewer.getUserName()));
		// check that there is no error
		assertEquals("", reviewList.reviewErrorMessage);
		// check that the review was  posted
		assertEquals(3, reviewList.getAllReviewsByQuestion(1).size());
		assertEquals(notTooLong, reviewList.getReview(3).getContents());
	}
	
	/**
	 * This test ensures that reviews can have 10, but not less than 10 characters.
	 * @see Review.Review
	 * @see Review.ReviewList#addReview(int, int, String, String)
	 */
	@Test
	public void goodShortReview() {
		String notTooShort = "This is 10";
		assertEquals(10, notTooShort.length());
		// attempt to post a review with 10 characters
		assertTrue(reviewList.addReview(1, 1, notTooShort, reviewer.getUserName()));
		// check that there is no error
		assertEquals("", reviewList.reviewErrorMessage);
		// check that the review was  posted
		assertEquals(3, reviewList.getAllReviewsByQuestion(1).size());
		assertEquals(notTooShort, reviewList.getReview(3).getContents());
	}
	
	/**
	 * This test ensures that reviews can have between 10 and 5000 characters, somewhere in the middle.
	 * @see Review.Review
	 * @see Review.ReviewList#addReview(int, int, String, String)
	 */
	@Test
	public void goodLengthReview() {
		assertEquals(60, validContents.length());
		// attempt to post a review with 60 characters
		assertTrue(reviewList.addReview(1, 1, validContents, reviewer.getUserName()));
		// check that there is no error
		assertEquals("", reviewList.reviewErrorMessage);
		// check that the review was  posted
		assertEquals(3, reviewList.getAllReviewsByQuestion(1).size());
		assertEquals(validContents, reviewList.getReview(3).getContents());
	}
	
	/**
	 * This test ensures that users other than the poster of a review can't edit it.
	 * @see Review.Review
	 * @see Review.ReviewList#editReview(int, String, String)
	 */
	@Test
	public void nonPosterEditor() {
		String contentsBefore = reviewList.getReview(1).getContents();
		// reviewer2 attempts to edit reviewer's review, should be false
		assertFalse(reviewList.editReview(1, validContents, reviewer2.getUserName()));
		// check that the review was not edited
		assertEquals(contentsBefore, reviewList.getReview(1).getContents());
	}
	
	/**
	 * This test ensures that the poster of a review can edit it.
	 * @see Review.Review
	 * @see Review.ReviewList#editReview(int, String, String)
	 */
	@Test
	public void posterEditor() {
		// reviewer attempts to edit their review
		assertTrue(reviewList.editReview(1, validContents, reviewer.getUserName()));
		// check that the review was  edited
		assertEquals(validContents, reviewList.getReview(1).getContents());
	}
	
	/**
	 * This test ensures that reviews can't be edited to have less than 10 characters.
	 * @see Review.Review
	 * @see Review.ReviewList#editReview(int, String, String)
	 */
	@Test
	public void tooShortEdit() {
		String contentsBefore = reviewList.getReview(1).getContents();
		String tooShort = "this is a";
		assertEquals(9, tooShort.length());
		// attempt to edit a review with too short of contents
		assertFalse(reviewList.editReview(1, tooShort, reviewer.getUserName()));
		// check that there is the correct error
		assertEquals("Contents must be at least 10 characters.\n", reviewList.reviewErrorMessage);
		// check that the review was not edited
		assertEquals(contentsBefore, reviewList.getReview(1).getContents());
	}
	
	/**
	 * This test ensures that reviews can't be edited to have more than 5000 characters.
	 * @see Review.Review
	 * @see Review.ReviewList#editReview(int, String, String)
	 */
	@Test
	public void tooLongEdit() {
		String contentsBefore = reviewList.getReview(1).getContents();
		String tooLong = "";
		for(int i = 0; i < 5001; i++)
			tooLong += "A";
		assertEquals(5001, tooLong.length());
		// attempt to edit a review with too long of contents
		assertFalse(reviewList.editReview(1, tooLong, reviewer.getUserName()));
		// check that there is the correct error
		assertEquals("Contents must be no more than 5000 characters.\n", reviewList.reviewErrorMessage);
		// check that the review was not edited
		assertEquals(contentsBefore, reviewList.getReview(1).getContents());
	}
	
	/**
	 * This test ensures that reviews can be edited to have 5000, but not over 5000 characters.
	 * @see Review.Review
	 * @see Review.ReviewList#editReview(int, String, String)
	 */
	@Test
	public void goodLongEdit() {
		String notTooLong = "";
		for(int i = 0; i < 5000; i++)
			notTooLong += "A";
		assertEquals(5000, notTooLong.length());
		// attempt to edit a review to 5000 characters
		assertTrue(reviewList.editReview(1, notTooLong, reviewer.getUserName()));
		// check that there is no error
		assertEquals("", reviewList.reviewErrorMessage);
		// check that the review was edited
		assertEquals(notTooLong, reviewList.getReview(1).getContents());
	}
	
	/**
	 * This test ensures that reviews can be edited to have 10, but not less than 10 characters.
	 * @see Review.Review
	 * @see Review.ReviewList#editReview(int, String, String)
	 */
	@Test
	public void goodShortEdit() {
		String notTooShort = "This is 10";
		assertEquals(10, notTooShort.length());
		// attempt to edit a review to 10 characters
		assertTrue(reviewList.editReview(1, notTooShort, reviewer.getUserName()));
		// check that there is no error
		assertEquals("", reviewList.reviewErrorMessage);
		// check that the review was edited
		assertEquals(notTooShort, reviewList.getReview(1).getContents());
	}
	
	/**
	 * This test ensures that reviews can have between 10 and 5000 characters, somewhere in the middle.
	 * @see Review.Review
	 * @see Review.ReviewList#editReview(int, String, String)
	 */
	@Test
	public void goodLengthEdit() {
		assertEquals(60, validContents.length());
		// attempt to edit a review to 60 characters
		assertTrue(reviewList.editReview(1, validContents, reviewer.getUserName()));
		// check that there is no error
		assertEquals("", reviewList.reviewErrorMessage);
		// check that the review was edited
		assertEquals(validContents, reviewList.getReview(1).getContents());
	}
	
	/**
	 * This test ensures that users other than the review poster can't delete a review.
	 * @see Review.Review
	 * @see Review.ReviewList#deleteReview(int, String)
	 */
	@Test
	public void nonPosterDeleter() {
		// someone who is not the poster attempts to delete the review
		assertFalse(reviewList.deleteReview(1, reviewer2.getUserName()));
		// check that the review was not deleted
		assertEquals(2, reviewList.getAllReviewsByQuestion(1).size());
	}
	
	/**
	 * This test ensures that the review poster can delete the review.
	 * @see Review.Review
	 * @see Review.ReviewList#deleteReview(int, String)
	 */
	@Test
	public void posterDeleter() {
		// the poster attempts to delete the review
		assertTrue(reviewList.deleteReview(1, reviewer.getUserName()));
		// check that the review was deleted
		assertEquals(1, reviewList.getAllReviewsByQuestion(1).size());
	}
	
	/**
	 * This test ensures that the admin can delete any review, even if they are not the poster.
	 * @see Review.Review
	 * @see Review.ReviewList#deleteReview(int, String)
	 */
	@Test
	public void adminDeleter() {
		// the poster attempts to delete the review
		assertTrue(reviewList.deleteReview(1, admin.getUserName()));
		// check that the review was deleted
		assertEquals(1, reviewList.getAllReviewsByQuestion(1).size());
	}
	
	/**
	 * This test ensures that users other than the review poster and the private message sender can not see the private message.
	 * @see Review.Review
	 * @see QuestionAndAnswer.Answer
	 */
	@Test
	public void nonAnswerViewer() {
		// check that the answer is private
		assertTrue(answerList.getAnswersByReview(1).get(0).getPrivate());
	}
	
	/**
	 * This test ensures that the review poster can see all private messages related to a review.
	 * @see Review.Review
	 * @see QuestionAndAnswer.Answer
	 */
	@Test
	public void answerViewer() {
		// check that the answer is private
		assertTrue(answerList.getAnswersByReview(1).get(0).getPrivate());
	}
	
	/**
	 * This test ensures that the private message sender can see all private messages related to their message.
	 * @see Review.Review
	 * @see QuestionAndAnswer.Answer
	 */
	@Test
	public void answerViewer2() {
		// check that the answer is private
		assertTrue(answerList.getAnswersByReview(1).get(0).getPrivate());
	}
	
	@After
	public void disconnectFromDatabase() {
		// close connection to database
		databaseHelper.closeConnection();
	}

}
